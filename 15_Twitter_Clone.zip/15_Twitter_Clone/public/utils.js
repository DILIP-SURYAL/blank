function showMessage(message, isError = true) {
    const alert = document.createElement('div');
    
    const type = isError ? 'danger' : 'success';
    alert.className = `alert alert-${type} position-fixed top-0 start-50 translate-middle-x mt-3 shadow`;
    alert.style.zIndex = '9999';
    alert.innerText = message;

    document.body.appendChild(alert);

    setTimeout(() => alert.remove(), 3000);
}
