function showMessage(message, isError = true) {
  const alert = document.createElement('div');

  const type = isError ? 'danger' : 'success';
  alert.className = `alert alert-${type} position-fixed top-0 start-50 translate-middle-x mt-3 shadow`;
  alert.style.zIndex = '9999';
  alert.innerText = message;

  document.body.appendChild(alert);

  setTimeout(() => alert.remove(), 3000);
}

async function loadUserProfile() {
  try {
    const token = localStorage.getItem('accessToken');
    const response = await fetch('/user/getProfile', {
      headers: { Authorization: `Bearer ${token}` },
    });

    if (!response.ok) {
      alert('You are unauthorized to see this page');
      window.location.href = '/';
      return;
    }

    let profileResult = await response.json();
    const data = profileResult.data;

    let tweetData = [];
    let followerData = [];
    let followingData = [];
    const [tweetRes, followerRes, followingRes] = await Promise.all([
      fetch(`/api/tweet/user/${data.user_id}`, { headers: { Authorization: `Bearer ${token}` } }),
      fetch(`/api/follows/${data.user_id}/followers`, {
        headers: { Authorization: `Bearer ${token}` },
      }),
      fetch(`/api/follows/${data.user_id}/following`, {
        headers: { Authorization: `Bearer ${token}` },
      }),
    ]);
    fetch(`/api/tweet/user/${data.user_id}`, { headers: { Authorization: `Bearer ${token}` } });
    tweetData = tweetRes.ok ? (await tweetRes.json()).data : [];
    followerData = followerRes.ok ? (await followerRes.json()).data : [];
    followingData = followingRes.ok ? (await followingRes.json()).data : [];

    const likeResponse = await fetch(`/api/tweet/user/likes/auth`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    let likeData = likeResponse.ok ? (await likeResponse.json()).data : [];

    const formattedDate = new Date(data.created_at).toLocaleDateString('en-US', {
      month: 'long',
      year: 'numeric',
    });

    // Construct the Profile UI
    let html = `
      <div class="sticky-header">
        <span style="cursor:pointer; font-size: 20px;" onclick="window.history.back()">←</span>
        <div>
          <h2>${data.username}</h2>
          <span style="font-size:13px; color:var(--text-gray)">${tweetData} Posts</span>
        </div>
      </div>

      <div class="banner-container">
        <img src='/upload/${data.cover_image || 'default-banner.png'}'>
      </div>

      <div class="profile-meta">
        <div class="avatar-container">
          <img src='/upload/${data.profile_picture || 'default-profile.png'}'>
        </div>
        <div class="action-bar">
          <button id="editProfileBtn" class="edit-btn">Edit profile</button>
        </div>
        <div class="user-info">
          <h2>${data.first_name} ${data.last_name}</h2>
          <p class="handle">@${data.username}</p>
          <p class="bio">${data.bio || 'Edit profile and enter your bio'}</p>
          <div class="details-row">
            <span>📍 ${data.timezone || 'Not set'}</span>
            <span>📅 Joined ${formattedDate}</span>
          </div>
          <div class="follow-stats">
            <span id="followingCount"><strong>${followingData.length}</strong> Following</span>
            <span id="followerCount"><strong>${followerData.length}</strong> Followers</span>
          </div>
        </div>
      </div>

      <div class="tabs">
        <div class="tab active" id="postsTab">Posts</div>
        <div class="tab" id="repliesBtn">Replies</div>
        <div class="tab" id="likesBtn">Likes</div>
      </div>

      <div id="content-container">
        ${renderTweets(tweetData, data)}
      </div>`;

    document.getElementById('middle-section').innerHTML = html;

    const modal = document.getElementById('editModal');
    const editBtn = document.getElementById('editProfileBtn');
    const closeBtn = document.getElementById('closeModal');

    editBtn.onclick = () => {
      // Fill current data into inputs
      document.getElementById('editFirstName').value = data.first_name;
      document.getElementById('editLastName').value = data.last_name;
      document.getElementById('date_of_birth').value = new Date(data.date_of_birth)
        .toLocaleString()
        .split(',')[0];

      document.getElementById('editBio').value = data.bio || '';
      document.getElementById('previewBanner').src =
        `/upload/${data.cover_image || 'default-banner.png'}`;
      document.getElementById('previewAvatar').src =
        `/upload/${data.profile_picture || 'default-profile.png'}`;

      modal.style.display = 'flex';
    };

    closeBtn.onclick = () => (modal.style.display = 'none');
    window.onclick = (e) => {
      if (e.target == modal) modal.style.display = 'none';
    };

    document.getElementById('postsTab').addEventListener('click', async () => {
      console.log('Fetching user tweets for user_id:', data.user_id);

      const tweetResponse = await fetch(`/api/tweet/user/${data.user_id}`, {
        headers: { Authorization: `Bearer ${token}` },
      });

      const freshTweetData = tweetResponse.ok ? (await tweetResponse.json()).data : [];

      updateTabs('postsTab');
      document.getElementById('content-container').innerHTML = renderTweets(freshTweetData, data);
    });

    document.getElementById('repliesBtn').addEventListener('click', async () => {
      const commentsResponse = await fetch(`/api/tweet/user/comments/auth`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      let commentData = commentsResponse.ok ? (await commentsResponse.json()).data : [];

      updateTabs('repliesBtn');
      console.log(commentData);
      document.getElementById('content-container').innerHTML = renderComments(commentData, data);
    });
    document.getElementById('likesBtn').addEventListener('click', async () => {
      const likeResponse = await fetch(`/api/tweet/user/likes/auth`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      let likeData = likeResponse.ok ? (await likeResponse.json()).data : [];
      updateTabs('likesBtn');
      console.log(likeData);
      document.getElementById('content-container').innerHTML = renderLikedTweets(likeData, data);
    });

    document
      .getElementById('followerCount')
      .addEventListener('click', () => renderFollower(data.user_id));
    document
      .getElementById('followingCount')
      .addEventListener('click', () => renderFollowing(data.user_id));
  } catch (e) {
    console.error('Profile Load Error:', e);
  }
}

function renderTweets(tweets, user) {
  console.log('this is tweets :', tweets);
  if (!tweets || tweets.length === 0) {
    return `
      <div style="padding: 40px; text-align: center;">
        <h3 style="margin-bottom: 8px;">No posts yet</h3>
        <p style="color: var(--text-gray);">Stay tuned for updates.</p>
      </div>`;
  }

  return tweets
    .map(
      (tweet) => `
    <article class="post-card">
      <img src="/upload/${user.profile_picture || 'default-profile.png'}" class="post-avatar">
      <div class="post-content">
        <div class="post-header">
          <strong>${user.first_name} ${user.last_name}</strong> <span>@${user.username}</span>
        </div>
        <div class="post-text">${tweet.tweet_content}</div>
        ${tweet.tweet_image ? `<div class="post-image"><img src="/upload/${tweet.tweet_image}"></div>` : ''}
        <div class="post-actions">
          <span>💬 ${tweet.comment_count || 0}</span>
          <span>❤️ ${tweet.like_count || 0}</span>
        </div>
      </div>
    </article>
  `,
    )
    .join('');
}

function renderFeed(tweets) {
  if (!tweets || tweets.length === 0) {
    return `
      <div style="padding: 60px 40px; text-align: center;">
        <h3 style="margin-bottom: 8px; font-size: 20px;">No posts yet</h3>
        <p style="color: var(--text-gray);">When people you follow post, they'll show up here.</p>
      </div>`;
  }

  return tweets
    .map((tweet) => {
      // Destructure for cleaner code
      const { author } = tweet;

      return `
      <article class="post-card">
        <!-- User Avatar from Author Object -->
        <img src="/upload/${author.profile_picture || 'default-profile.png'}" class="post-avatar">
        
        <div class="post-content">
          <div class="post-header">
            <!-- Username from Author Object -->
            <strong>${author.username.split('@')[0]}</strong> 
            <span class="handle">@${author.username}</span>
          </div>

          <!-- Tweet Content -->
          <div class="post-text">${tweet.tweet_content}</div>

          <!-- Conditional Image Rendering -->
          ${
            tweet.tweet_image
              ? `
            <div class="post-image">
              <img src="/upload/${tweet.tweet_image}" alt="Tweet Image">
            </div>`
              : ''
          }

          <!-- Stats & Actions -->
          <div class="post-actions">
            <div class="action-item">💬 <span>${tweet.comment_count}</span></div>
            <div class="action-item">🔁 <span>${tweet.retweet_count}</span></div>
            <div class="action-item">❤️ <span>${tweet.like_count}</span></div>
          </div>
        </div>
      </article>
    `;
    })
    .join('');
}

function updateTabs(activeId) {
  document.querySelectorAll('.tab').forEach((t) => t.classList.remove('active'));
  document.getElementById(activeId).classList.add('active');
}

function renderComments(comments) {
  if (!comments || comments.length === 0) {
    return '';
  }

  return `
    <div class="comments-section">
      ${comments
        .map(
          (comment) => `
        <div class="comment-card">
          <img src="/upload/${comment.profile_picture || 'default-profile.png'}" class="comment-avatar">
          <div class="comment-content">
            <div class="comment-header">
              <strong>${comment.first_name}</strong> 
              <span class="handle">@${comment.username}</span>
            </div>
            <div class="reply-label">Replying to <span>@${comment.reply_to_username || 'username'}</span></div>
            <div class="comment-text">${comment.comment_content}</div>
          </div>
        </div>
      `,
        )
        .join('')}
    </div>`;
}

function renderLikedTweets(likedTweets) {
  if (!likedTweets || likedTweets.length === 0) {
    return `
      <div style="padding: 40px; text-align: center;">
        <h3 style="margin-bottom: 8px;">No likes yet</h3>
        <p style="color: var(--text-gray);">You haven't liked any posts yet. When you do, they'll show up here.</p>
      </div>`;
  }

  return likedTweets
    .map(
      (tweet) => `
    <article class="post-card">
      <img src="/upload/${tweet.profile_picture || 'default-profile.png'}" class="post-avatar">
      <div class="post-content">
        <div class="post-header">
          <strong>${tweet.first_name} ${tweet.last_name}</strong> <span>@${tweet.username}</span>
        </div>
        <div class="post-text">${tweet.tweet_content}</div>
        ${tweet.tweet_image ? `<div class="post-image"><img src="/upload/${tweet.tweet_image}"></div>` : ''}
        <div class="post-actions">
          <span>💬 ${tweet.comment_count || 0}</span>
          <span style="color: #f91880;">❤️ ${tweet.like_count || 0}</span>
        </div>
      </div>
    </article>
  `,
    )
    .join('');
}

async function loadUserFeed() {
  try {
    let token = localStorage.getItem('accessToken');
    const response = await fetch('/api/tweet-feed', {
      headers: { Authorization: `Bearer ${token}` },
    });

    if (!response.ok) {
      alert('You are unauthorized to see this page');
    }

    let feedData = (await response.json()).data || [];

    console.log(feedData);
    let html = `<div class="sticky-header">
    <h2 style="font-size: 20px; font-weight: 800;">Home</h2>
  </div>

  <!-- Tweet Composer -->
  <div class="composer-container">
    <img src="/upload/default-profile.png" class="post-avatar" id="composer-avatar">
    <div class="composer-content">
      <textarea placeholder="What's happening?!" id="tweet-input"></textarea>
      
      <!-- Preview Image (hidden by default) -->
      <div id="image-preview-container" style="display: none; position: relative; margin-bottom: 10px;">
        <span id="remove-preview" style="position: absolute; right: 10px; top: 10px; background: rgba(0,0,0,0.7); color: white; border-radius: 50%; width: 25px; height: 25px; display: flex; align-items: center; justify-content: center; cursor: pointer;">✕</span>
        <img id="image-preview" src="" style="width: 100%; border-radius: 16px; border: 1px solid var(--border-color);">
      </div>

      <div class="composer-actions">
        <label class="icon-btn">
          📷 <input type="file" id="tweet-image-input" hidden accept="image/*">
        </label>
        <button class="tweet-btn-small" id="submit-tweet" disabled>Post</button>
      </div>
    </div>
  </div>

  <!-- Feed Container -->
  <div id="feed-container">
    ${renderFeed(feedData)}
  </div>`;

    document.getElementById('middle-section').innerHTML = html;
  } catch (e) {
    console.log(e);
    throw e;
  }
}

async function renderFollower(user_id) {
  try {
    let token = localStorage.getItem('accessToken');

    const response = await fetch(`/api/follows/${user_id}/followers`, {
      headers: { Authorization: `Bearer ${token}` },
    });

    if (!response.ok) {
      alert('Unable to load followers');
      return;
    }

    let followerData = (await response.json()).data || [];

    let html = `
<div class="sticky-header">
  <span style="cursor:pointer; font-size: 20px;" onclick="window.history.back()">←</span>
  <h2 style="font-size: 20px; font-weight: 800;">Followers</h2>
</div>

<div class="followers-list">
  ${followerData
    .map(
      (follower) => `
    <div class="follower-card">
      <img src="/upload/${follower.profile_picture || 'default-profile.png'}" class="follower-avatar">

      <div class="follower-info">
        <strong>${follower.first_name}</strong>
        <span>@${follower.username}</span>
      </div>

      <button 
        class="follow-btn"
        onclick="follow(${follower.user_id}, this)"
      >
        Follow
      </button>
    </div>
  `,
    )
    .join('')}
</div>`;

    document.getElementById('middle-section').innerHTML = html;
  } catch (e) {
    console.log(e);
  }
}
async function renderFollowing(user_id) {
  try {
    let token = localStorage.getItem('accessToken');

    const response = await fetch(`/api/follows/${user_id}/following`, {
      headers: { Authorization: `Bearer ${token}` },
    });

    if (!response.ok) {
      alert('Unable to load following');
      return;
    }

    let followerData = (await response.json()).data || [];

    let html = `
<div class="sticky-header">
  <span style="cursor:pointer; font-size: 20px;" onclick="window.history.back()">←</span>
  <h2 style="font-size: 20px; font-weight: 800;">Following</h2>
</div>

<div class="followers-list">
  ${followerData
    .map(
      (follower) => `
    <div class="follower-card">
      <img src="/upload/${follower.profile_picture || 'default-profile.png'}" class="follower-avatar">

      <div class="follower-info">
        <strong>${follower.first_name}</strong>
        <span>@${follower.username}</span>
      </div>

      <button 
        class="follow-btn following"
        onclick="unfollow(${follower.user_id}, this)"
      >
        Following
      </button>
    </div>
  `,
    )
    .join('')}
</div>`;

    document.getElementById('middle-section').innerHTML = html;
  } catch (e) {
    console.log(e);
  }
}

//  document.getElementById('profile').addEventListener('click', async (e) => {
//     e.preventDefault();

//     try {

//       const token = localStorage.getItem("accessToken");

//       const response = await fetch("/user/getProfile", {
//         method: 'GET',
//         headers: {
//           "Authorization": `Bearer ${token}`, // Added Bearer token
//           "Content-Type": "application/json"
//         },
//       });
//       if (response.ok) {
//         let data = await response.json();
//         console.log(data.data)

//         loadUserProfile(data.data)
//       } else {
//         window.location.href = "/"
//       }
//     }
//     catch (error) {
//       console.error("Network error:", error);
//       showMessage("Something went wrong. Try again.", true);
//     }
//   });

//   function loadUserProfile(data) {
//     let html = ` <div class="profile-header">
//         <h2>${data.first_name} ${data.last_name}</h2>
//         <span style="color: gray;">0 Tweets</span>
//       </div>
//       <div class="profile-banner"></div>
//       <div class="profile-info">
//         <div class="avatar"></div>
//         <h3>@${data.username}</h3>
//         <p>${data.bio || "enter your bio"}</p>

//       </div>`;

//     document.getElementById('container').innerHTML = html;
//   }

//   document.getElementById('logout-btn').addEventListener("click", async (e) => {

//     try {

//       const token = localStorage.getItem("accessToken");

//       const response = await fetch("/logout", {
//         method: 'POST',
//         headers: {
//           "Authorization": `Bearer ${token}`, // Added Bearer token
//           "Content-Type": "application/json"
//         },
//       });
//       if (response.ok) {
//         localStorage.removeItem("accessToken")
//         let data = await response.json();
//         console.log(data.data)
//         window.location.href = "/"
//       } else {
//         showMessage("unable to logout")
//       }
//     }
//     catch (error) {
//       console.error("Network error:", error);
//       showMessage("Something went wrong. Try again.", true);
//     }
//   }

//   )

async function follow(id) {
  try {
    const token = localStorage.getItem('accessToken');
    const response = await fetch(`/api/follows/${id}`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
    });

    if (!response.ok) {
      showMessage('Unable to update follow status');
      return;
    }

    const result = await response.json();
    const isFollowing = result.data.isFollowing;

    btn.textContent = isFollowing ? 'Unfollow' : 'Follow';
  } catch (e) {
    console.log(e);
    showMessage('Something went wrong. Try again.', true);
  }
}

async function unfollow(id) {
  try {
    const token = localStorage.getItem('accessToken');
    const response = await fetch(`/api/follows/${id}`, {
      method: 'DELETE',
      headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
    });

    if (!response.ok) {
      showMessage('Unable to update follow status');
      return;
    }

    const result = await response.json();
    const isFollowing = result.data.isFollowing;

    // btn.textContent = isFollowing ? 'Unfollow' : 'Follow';
  } catch (e) {
    console.log(e);
    showMessage('Something went wrong. Try again.', true);
  }
}
