export interface ICreateUser {
  first_name: string;
  last_name: string;
  username: string;
  email:string,
  timezone:string,
  user_password:string,
}


export interface User {
  user_id:number
  first_name: string;
  last_name: string;
  username: string;
  email:string,
  user_password:string,
  bio?:string,
  profile_picture : string,
  cover_image :string,
}
