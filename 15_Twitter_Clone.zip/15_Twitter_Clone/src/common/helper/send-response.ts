import type { Response } from 'express';

export function sendResponse<T>(
    res: Response,
    statusCode: number,
    data: T | null,
    message: string,
    error?: string,
) {
    return res.status(statusCode).json({ data, message, error });
}


export type ApiResponse<T> = {
    data: T | null;
    message : string;
    error? : string;
}