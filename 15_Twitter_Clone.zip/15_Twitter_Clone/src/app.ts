import express from 'express';
import { env } from './config/index.js';
import type { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import session from 'express-session';
import cookieParser from 'cookie-parser';
import { buildApiRouter } from './routes/index.js';

export function createApp() {
  const app = express();

  console.log(env.DB_HOST);

  let __filePath = fileURLToPath(import.meta.url);
  let __dirname = path.dirname(__filePath);

  //configuring ejs settings ___________________________
  app.set('view engine', 'ejs');
  app.set('views', path.join(__dirname, 'views'));

  //configuring static file serving_____________________
  app.use(express.static(path.join(__dirname, 'upload')));
  app.use(express.static(path.join(__dirname, '../public')));
  app.use('/css', express.static(path.join(__dirname, '../node_modules/bootstrap/dist/css')));
  app.use('/js', express.static(path.join(__dirname, '../node_modules/bootstrap/dist/js')));

  // <link rel="stylesheet" href="/css/bootstrap.min.css">
  // <script src="/js/bootstrap.bundle.min.js"></script>

  //configuring the bodyparser___________________________
  app.use(express.json());
  app.use(
    session({ secret: 'scret', resave: false, saveUninitialized: true, cookie: { secure: false } }),
  );
  app.use(express.urlencoded({ extended: true }));
  app.use(cookieParser());

  //routes
  app.use(buildApiRouter());
  

  // This matches everything (*) that hasn't been caught yet
  app.use((req: Request, res: Response) => {
    res.status(404).render('auth/error');
  });

  return app;
}
