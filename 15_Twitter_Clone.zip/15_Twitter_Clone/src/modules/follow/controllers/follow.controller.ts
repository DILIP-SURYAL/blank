import type { Request, Response } from "express"
import { sendResponse } from "../../../common/helper/send-response.js";
import { HttpException } from "../../../common/helper/http-exception.js";
import { FollowServices } from "../services/follow.services.js";

export class FollowController {

    followService = new FollowServices();
    followUser = async (req: Request, res: Response) => {
        try {
            let follower_id = req.authUser?.user_id as number;

            let following_id = Number(req.params.id);




            let user = await this.followService.followUser(follower_id, following_id);

            sendResponse(res, 200, user, "follow successfull");
        }
        catch (e) {
            console.log(e);
            let error = e instanceof Error ? e.message : "error in registring user";
            const status = e instanceof HttpException ? e.statusCode : 400;
            return sendResponse(res, status, "Failed to send otp", error);
        }
    }

    unfollowUser = async (req: Request, res: Response) => {
        try {
            let follower_id = req.authUser?.user_id as number;
            let following_id = Number(req.params.id);
            let user = await this.followService.unfollowUser(follower_id, following_id);

            sendResponse(res, 200, user, "unfollow successfull");



        }
        catch (e) {
            console.log(e);
            let error = e instanceof Error ? e.message : "error in registring user";
            const status = e instanceof HttpException ? e.statusCode : 400;
            return sendResponse(res, status, "Failed to send otp", error);
        }
    }

    getFollowers = async (req: Request, res: Response) => {
        try {

            let target_id = req.params.id === 'me' ? req.authUser?.user_id as number : Number(req.params.id);


            let followers = await this.followService.getFollowers(target_id);
            sendResponse(res, 200, followers, "followers fetched successfully")

        }
        catch (e) {
            console.log(e);
            let error = e instanceof Error ? e.message : "error in registring user";
            const status = e instanceof HttpException ? e.statusCode : 400;
            return sendResponse(res, status, "Failed to send otp", error);
        }
    }

    getFollowings = async (req: Request, res: Response) => {
        try {
            let target_id = req.params.id === 'me' ? req.authUser?.user_id as number : Number(req.params.id);
            let following = await this.followService.getFollowings(target_id);
            sendResponse(res, 200, following, "following fetched successfully")

        }
        catch (e) {
            console.log(e);
            let error = e instanceof Error ? e.message : "error in registring user";
            const status = e instanceof HttpException ? e.statusCode : 400;
            return sendResponse(res, status, "Failed to send otp", error);
        }
    }
}