import { ConflictException } from "../../../common/helper/http-exception.js";
import { FollowModel } from "../model/follow.model.js";

export class FollowServices {


    followModel = new FollowModel();

    async followUser(follower_id: number, following_id: number) {
        let user = await this.followModel.followUser(follower_id, following_id);

        if (!user) {
            throw new ConflictException("unable to Follow the user");
        }
        return user;
    }

    async unfollowUser(follower_id: number, following_id: number) {
        let isUnfollowed = await this.followModel.unfollowUser(follower_id, following_id);
        return isUnfollowed;
    }

    async getFollowers(user_id: number) {
        let followers = await this.followModel.getFollowers(user_id);
        return followers;
    }

    async getFollowings(user_id: number) {
        let followings = await this.followModel.getFollowing(user_id);
        return followings;
    }

}