import type { ResultSetHeader, RowDataPacket } from "mysql2";
import pool from "../../../config/db.config.js";
import type { FollowUser } from "../interfaces/follow.interface.js";

export class FollowModel {
    async followUser(follower_id: number, following_id: number) {
        let [result] = await pool.query<ResultSetHeader>("insert into follows_tabl(follower_id, following_id) values(?,?)", [follower_id, following_id]);

        return {
            follow_id: result.insertId,
            follower_id,
            following_id
        }
    }
    async unfollowUser(follower_id: number, following_id: number): Promise<boolean> {

        let [result] = await pool.query<ResultSetHeader>("delete from follows_tabl where follower_id= ? and following_id=?", [follower_id, following_id]);
        return result.affectedRows > 0
    }
    async getFollowers(user_id: number): Promise<FollowUser[]> {
        let [rows] = await pool.query<RowDataPacket[]>("SELECT u.user_id, u.username, u.first_name, u.profile_picture, EXISTS(SELECT 1 FROM follows_tabl WHERE follower_id = ? AND following_id = u.user_id) as isFollow FROM follows_tabl f JOIN users u ON u.user_id = f.follower_id WHERE f.following_id = ?;", [user_id, user_id]);
        return rows as FollowUser[];
    }
    async getFollowing(user_id: number): Promise<FollowUser[]> {
        let [rows] = await pool.query<RowDataPacket[]>("select u.user_id, u.username, u.first_name, u.profile_picture from follows_tabl f join users u on u.user_id = f.following_id where f.follower_id=?", [user_id]);
        return rows as FollowUser[];
    }
    async isFollowing(follower_id: number, following_id: number): Promise<boolean> {

        let [rows] = await pool.query<RowDataPacket[]>("select follow_id from follows_tabl where follower_id = ? and following_id = ?", [follower_id, following_id])

        return rows.length > 0;
    }
    
}