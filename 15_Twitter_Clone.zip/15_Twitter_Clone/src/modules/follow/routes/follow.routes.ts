import { Router } from "express";
import type { Routes } from "../../../common/interfaces/routes.interface.js";
import { FollowController } from "../controllers/follow.controller.js";
import { authMiddleware } from "../../../middlewares/auth.middleware.js";

export class FollowRouter implements Routes{
    path = "/api"
    router = Router();

    followController = new FollowController();
    constructor(){
        this.initializeRoutes();
    }


    initializeRoutes(){
      this.router.get("/demo1",(req, res)=>{res.json("hi there")})

        //post /follows/:user_id - followuser
        this.router.post("/follows/:id",authMiddleware,this.followController.followUser);
        // delete /follows/:user_id - unfollow
        this.router.delete("/follows/:id",authMiddleware, this.followController.unfollowUser);

        // get follow/:user_id/followers  - for getting all follower of the usr
        this.router.get("/follows/:id/followers",authMiddleware,this.followController.getFollowers);

        // get follow/:user_id/following  - get all persons a user is follwoing
        this.router.get("/follows/:id/following",authMiddleware, this.followController.getFollowings);



    }
}