export interface FollowUser{
    user_id :number;
    username :string;
    first_name :string;
    profile_picture :string | null;
}

