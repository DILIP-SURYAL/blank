import { type Response, type Request ,Router } from "express";
import type { Routes } from "../../../common/interfaces/routes.interface.js";
import { UserController } from "../controllers/user.controller.js";
import { authMiddleware } from "../../../middlewares/auth.middleware.js";
import upload from "../../../middlewares/multer.middleware.js";

export class UserRouter implements Routes {

    path = "/user";
    router = Router();
    userController = new UserController();

    constructor() {
        this.initilizeRoutes();
    }

    initilizeRoutes() {
        

        this.router.get("/home",(req:Request, res:Response)=>{ res.render("user/home")})

        this.router.get("/getProfile",authMiddleware,this.userController.getProfile)
        this.router.post("/updateProfile",authMiddleware, upload.fields([{name:"profilePicture"}, {name:"coverImage"}]),this.userController.updateProfile)
    }
}