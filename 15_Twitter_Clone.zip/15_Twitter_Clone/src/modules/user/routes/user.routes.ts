import { Router } from "express";
import type { Routes } from "../../../common/interfaces/routes.interface.js";
import { UserController } from "../controllers/user.controller.js";

export class UserRouter implements Routes {

    path = "/user";
    router = Router();
    userController = new UserController();

    constructor() {
        this.initilizeRoutes();
    }

    initilizeRoutes() {
        this.router.get("/edit-profile",this.userController.editProfile);
        
    }
}