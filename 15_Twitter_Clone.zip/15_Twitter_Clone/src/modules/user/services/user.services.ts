import type { User } from "../../../common/interfaces/app.interfaces.js";
import type { IUpdateUser } from "../interfaces/user.interface.js";
import { UserModel } from "../models/user.model.js";

export class UserService {

    userModel = new UserModel();

    async getProfile(user_id: number): Promise<User | null> {
        const user = await this.userModel.findById(user_id);

        if (!user) return null;

        const { user_password, ...publicUser } = user;

        return publicUser as User;
    }

    async updateProfile(data : IUpdateUser, id: number) : Promise<boolean>{

        console.log("in update profile services", data)
        let isUpdated = this.userModel.updateUser(data, id);
        return isUpdated;
    }
}