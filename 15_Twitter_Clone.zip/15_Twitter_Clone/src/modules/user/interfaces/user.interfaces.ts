export interface IUser {
  user_id: number;
  first_name: string | null;
  last_name: string | null;
  username: string;
  email: string;
  user_password: string;
  bio: string | null;
  profile_picture: string | null;
  cover_image: string | null;
  timezone: string;
  created_at: Date;
  updated_at: Date;
  is_deleted: boolean;
}

export interface ICreateUser {
  username: string;
  email: string;
  user_password: string;
  first_name?: string;
  last_name?: string;
}

export interface IUpdateUser {
  first_name?: string;
  last_name?: string;
  bio?: string;
  profile_picture?: string;
  cover_image?: string;
  timezone?: string;
}

export interface IUserPublic {
  user_id: number;
  username: string;
  first_name: string | null;
  last_name: string | null;
  bio: string | null;
  profile_picture: string | null;
  cover_image: string | null;
  created_at: Date;
}

export type ApiResponse<T> = {
  data: T;
  message: string;
};