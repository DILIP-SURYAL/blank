export interface IUser {
  userId: number;
  firstName: string;
  lastName: string;
  username: string;
  email: string;
  bio: string | null;
  profilePicture: string | null;
  coverImage: string | null;
  timezone: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface ICreateUser {
  firstName: string;
  lastName: string;
  username: string;
  email: string;
  password: string;
  timezone: string;
}

export interface IUpdateUser {
  first_name?: string;
  last_name?: string;
  username?: string;
  email?:string;
  bio?: string;
  profile_picture?: string;
  cover_image?: string;
  timezone?: string;
}
