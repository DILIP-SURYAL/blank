import type { ResultSetHeader, RowDataPacket } from "mysql2";
import type { ICreateUser, User } from "../../../common/interfaces/app.interfaces.js";
import pool from "../../../config/db.config.js";
    import type { IUpdateUser } from "../interfaces/user.interface.js";

export class UserModel {

       async findByEmail(email: string): Promise<User | null> {
              let [result] = await pool.query<RowDataPacket[]>("select * from users where email = ?", [email]);
              return result.length > 0 ? result[0] as User : null;
       }
       async findByUsername(username: string): Promise<User | null> {
              let [result] = await pool.query<RowDataPacket[]>("select * from users where username = ?", [username]);
              return result.length > 0 ? result[0] as User : null;
       }
       async findById(id: number): Promise<User | null> {
              let [result] = await pool.query<RowDataPacket[]>("select * from users where user_id = ?", [id]);
              return result.length > 0 ? result[0] as User : null;
       }

       async create({ first_name, last_name, username, email, user_password, timezone, date_of_birth }: ICreateUser): Promise<User | null> {
              let [result] = await pool.query<ResultSetHeader>("insert into users(first_name, last_name, username, email, user_password, timezone, date_of_birth) values(?,?,?,?,?,?,?)", [first_name, last_name, username, email, user_password, timezone,date_of_birth]);
              return this.findById(result.insertId);

       }

       async updatePassword(password : string, user_id : number){
              let [result] = await pool.query<ResultSetHeader>("update users set user_password = ? where user_id = ?",[password, user_id]);
              return result.affectedRows > 0;
       }
     

       async findByOtpAndEmail(email: string, otp: string) {
              let [result] = await pool.query<RowDataPacket[]>("select * from password_resets where otp = ? AND email = ?", [otp, email]);
              console.log(result);
              return result[0] ? true : false;

       }
       async getOtp(email: string): Promise<number | null> {
              const [rows] = await pool.query<RowDataPacket[]>(
                     "SELECT otp from password_resets where email = ?",
                     [email]
              );

              const result = rows[0];

              return result ? result.otp : null;
       }

       async updateUser(data: IUpdateUser, id: number): Promise<boolean> {
              const [result] = await pool.query<ResultSetHeader>(
                     "update users set first_name=?, last_name=?, bio=?, profile_picture=?, cover_image=? where user_id=?",
                     [data.first_name, data.last_name,  data.bio, data.profile_picture, data.cover_image, id]
              );


              return result.affectedRows > 0;
       }
       async canGetOtp(email: string): Promise<boolean> {
              let otp = await this.getOtp(email);
              if (!otp) return true;
              let [rows] = await pool.query<RowDataPacket[]>("SELECT * FROM password_resets WHERE email = ? AND otp = ? AND expires_at > NOW() LIMIT 1", [email, otp]);
              const result = rows[0];
              return result ? false : true;
       }


       async findByNameOrEmailOrUser(searchString : string){

              let data = `%${searchString}%`
              let [result] = await pool.query<RowDataPacket[]>("select u.user_id, u.first_name, u.profile_picture, u.last_name , u.username from users u where u.first_name like ? or u.last_name like ? or u.username like ?",[data, data,data]);


              return result;
       }





}