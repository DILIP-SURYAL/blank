import type { ResultSetHeader, RowDataPacket } from "mysql2";
import pool from "../../../config/db.config.js";
import type { ICreateUser, IUser } from "../interfaces/user.interfaces.js";

export class UserModel {

  // ─── Finders ───────────────────────────────────────────────────────────────

  async findByEmail(email: string): Promise<IUser | null> {
    const [rows] = await pool.query<RowDataPacket[]>(
      "SELECT * FROM users WHERE email = ? AND is_deleted = FALSE LIMIT 1",
      [email]
    );
    return rows.length > 0 ? (rows[0] as IUser) : null;
  }

  async findByUsername(username: string): Promise<IUser | null> {
    const [rows] = await pool.query<RowDataPacket[]>(
      "SELECT * FROM users WHERE username = ? AND is_deleted = FALSE LIMIT 1",
      [username]
    );
    return rows.length > 0 ? (rows[0] as IUser) : null;
  }

  async findById(id: number): Promise<IUser | null> {
    const [rows] = await pool.query<RowDataPacket[]>(
      "SELECT * FROM users WHERE user_id = ? AND is_deleted = FALSE LIMIT 1",
      [id]
    );
    return rows.length > 0 ? (rows[0] as IUser) : null;
  }

  // Useful for login — find by either email or username in one query
  async findByEmailOrUsername(emailOrUsername: string): Promise<IUser | null> {
    const [rows] = await pool.query<RowDataPacket[]>(
      `SELECT * FROM users
       WHERE (email = ? OR username = ?) AND is_deleted = FALSE
       LIMIT 1`,
      [emailOrUsername, emailOrUsername]
    );
    return rows.length > 0 ? (rows[0] as IUser) : null;
  }

  // ─── Create ────────────────────────────────────────────────────────────────

  async create(data: ICreateUser): Promise<IUser> {
    const { first_name = null, last_name = null, username, email, user_password } = data;

    const [result] = await pool.query<ResultSetHeader>(
      `INSERT INTO users (first_name, last_name, username, email, user_password)
       VALUES (?, ?, ?, ?, ?)`,
      [first_name, last_name, username, email, user_password]
    );

    const newUser = await this.findById(result.insertId);
    if (!newUser) throw new Error("User creation failed — could not retrieve inserted row.");

    return newUser;
  }

  // ─── Password ──────────────────────────────────────────────────────────────

  async updatePassword(userId: number, hashedPassword: string): Promise<void> {
    await pool.query<ResultSetHeader>(
      "UPDATE users SET user_password = ? WHERE user_id = ? AND is_deleted = FALSE",
      [hashedPassword, userId]
    );
  }

  // ─── Soft Delete ───────────────────────────────────────────────────────────
  // Hard delete is never done — is_deleted flag keeps data integrity

  async softDelete(userId: number): Promise<void> {
    await pool.query<ResultSetHeader>(
      "UPDATE users SET is_deleted = TRUE WHERE user_id = ?",
      [userId]
    );
  }

  // ─── OTP ───────────────────────────────────────────────────────────────────

  async upsertOtp(email: string, otp: string): Promise<void> {
    // Delete any existing OTP first, then insert fresh — avoids duplicates
    await pool.query<ResultSetHeader>(
      "DELETE FROM password_resets WHERE email = ?",
      [email]
    );
    await pool.query<ResultSetHeader>(
      `INSERT INTO password_resets (otp, email, expires_at)
       VALUES (?, ?, NOW() + INTERVAL 2 MINUTE)`,
      [otp, email]
    );
  }

  async findValidOtp(email: string, otp: string): Promise<boolean> {
    const [rows] = await pool.query<RowDataPacket[]>(
      `SELECT 1 FROM password_resets
       WHERE email = ? AND otp = ? AND expires_at > NOW()
       LIMIT 1`,
      [email, otp]
    );
    return rows.length > 0;
  }

  async deleteOtp(email: string): Promise<void> {
    await pool.query<ResultSetHeader>(
      "DELETE FROM password_resets WHERE email = ?",
      [email]
    );
  }

  // ─── Existence Checks ──────────────────────────────────────────────────────
  // Lighter than findBy* — no need to hydrate a full IUser just to check existence

  async existsByEmail(email: string): Promise<boolean> {
    const [rows] = await pool.query<RowDataPacket[]>(
      "SELECT 1 FROM users WHERE email = ? AND is_deleted = FALSE LIMIT 1",
      [email]
    );
    return rows.length > 0;
  }

  async existsByUsername(username: string): Promise<boolean> {
    const [rows] = await pool.query<RowDataPacket[]>(
      "SELECT 1 FROM users WHERE username = ? AND is_deleted = FALSE LIMIT 1",
      [username]
    );
    return rows.length > 0;
  }
}