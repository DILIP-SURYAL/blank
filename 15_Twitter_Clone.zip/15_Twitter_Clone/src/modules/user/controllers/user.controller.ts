import { snapshot } from "node:test";
import { HttpException } from "../../../common/helper/http-exception.js";
import { sendResponse } from "../../../common/helper/send-response.js";
import type { IUpdateUser } from "../interfaces/user.interface.js";
import { UserService } from "../services/user.services.js";
import type { Request, Response } from "express";
export class UserController {

    userService = new UserService();

    getProfile = async (req: Request, res: Response) => {
        try {
            let userProfile = await this.userService.getProfile(req.authUser?.id);
            sendResponse(res, 200, userProfile, "Profile is fetched Successfully !!");
        }
        catch (e) {
            console.log(e);
            let error = e instanceof Error ? e.message : "error in registring user";
            const status = e instanceof HttpException ? e.statusCode : 400;
            return sendResponse(res, status, "Failed to send otp", error);
        }
    }

    updateProfile = async (req: Request, res: Response) => {
        try {
            let updateBody = req.body as IUpdateUser;

            // if (req.files?.profile == 'profilePicture') updateBody.profilePicture = req.file?.filename as string;
            // if (req.files?.fieldname == 'profilePicture') updateBody.profilePicture = req.file?.filename as string;


            if (!req.files) {
                return res.status(400).send("No file uploaded. Check your Postman Key name.");
            }

            console.log(req.file)

            await this.userService.updateProfile(updateBody, req.authUser.id);

            sendResponse(res, 200, null, "profile updated succesfully");

        } catch (e) {
            console.log(e);
            let error = e instanceof Error ? e.message : "error in registring user";
            const status = e instanceof HttpException ? e.statusCode : 400;
            return sendResponse(res, status, "Failed to send otp", error);
        }
    }
}