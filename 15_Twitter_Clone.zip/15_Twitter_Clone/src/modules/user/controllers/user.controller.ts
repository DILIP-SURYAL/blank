import { snapshot } from "node:test";
import { HttpException } from "../../../common/helper/http-exception.js";
import { sendResponse } from "../../../common/helper/send-response.js";
import type { IUpdateUser } from "../interfaces/user.interface.js";
import { UserService } from "../services/user.services.js";
import type { Request, Response } from "express";
export class UserController {

    userService = new UserService();

    getProfile = async (req: Request, res: Response) => {
        try {
            let user_id = req.authUser?.user_id as number;
            let userProfile = await this.userService.getProfile(user_id);
            sendResponse(res, 200, userProfile, "Profile is fetched Successfully !!");
        }
        catch (e) {
            console.log(e);
            let error = e instanceof Error ? e.message : "error in registring user";
            const status = e instanceof HttpException ? e.statusCode : 400;
            return sendResponse(res, status, "Failed to send otp", error);
        }
    }

    updateProfile = async (req: Request, res: Response) => {
        try {
            let updateBody = req.body as IUpdateUser;

            const files = req.files as Record<string , Express.Multer.File[]>
           
            
            const profile_picture= files['profile_picture']?.[0]?.filename;
            const cover_image = files['cover_image']?.[0]?.filename;
    
            let user_id = req.authUser?.user_id as number;

            if(profile_picture){
                updateBody.profile_picture = profile_picture;
            }
            if(cover_image){
                updateBody.cover_image = cover_image;
            }


            await this.userService.updateProfile(updateBody,user_id);

            sendResponse(res, 200, null, "profile updated succesfully");

        } catch (e) {
            console.log(e);
            let error = e instanceof Error ? e.message : "error in registring user";
            const status = e instanceof HttpException ? e.statusCode : 400;
            return sendResponse(res, status, "Failed to send otp", error);
        }
    }
}