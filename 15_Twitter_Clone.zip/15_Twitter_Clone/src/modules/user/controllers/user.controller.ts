import { UserService } from "../services/user.services.js";
import type { Request, Response } from "express";
export class UserController{

    userService = new UserService();
    
    editProfile = async (req:Request,res:Response) =>{
        try{
            
        }
        catch(e){
            throw e;
        }
    }
}