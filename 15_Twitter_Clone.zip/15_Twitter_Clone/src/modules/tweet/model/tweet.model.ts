import type { ResultSetHeader, RowDataPacket } from "mysql2";
import pool from "../../../config/db.config.js";
import type { createTweetResult } from "../interfaces/tweet.interface.js";

export class TweetModel{


    async createTweet(userId : number, content : string, imageUrl : string) : Promise<createTweetResult>{

        let [result] = await pool.query<ResultSetHeader>("insert into tweets(user_id, tweet_content, tweet_image) values(?,?,?)",[userId, content, imageUrl])

        return {
            tweet_id : result.insertId,
            tweet_content : content,
            tweet_image : imageUrl,
            created_at : new Date().toString()
        }

        
    }

    async getTweetById(tweetId : number, userId :number) {

        let [rows] = await pool.query<RowDataPacket[]>("select * from tweets where tweetId ")
    }

    async deleteTweet(tweetId : number){}
    
    async editTweet(tweetId: number, content : string, imageUrl :string){}

    async getFeedTweets(userId : number){}

    async getUserTweets(userId : number){}

    async toggleLike(tweetId : number , userId : number){}

    async retweet(tweetId : number, userId:number){}

    async createReply(tweetId:number, userId:number, content :string){}
    
    async getReplies(tweetId : number){}
}