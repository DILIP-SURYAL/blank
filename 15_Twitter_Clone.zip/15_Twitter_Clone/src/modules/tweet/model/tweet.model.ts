import type { ResultSetHeader, RowDataPacket } from "mysql2";
import pool from "../../../config/db.config.js";
import type { Comment, createTweetResult, FullComment, Tweet } from "../interfaces/tweet.interface.js";
import { UserModel } from "../../user/models/user.model.js";


export class TweetModel {

    userModel = new UserModel();

    async createTweet(userId: number, content: string, tweet_image: string | null): Promise<createTweetResult> {

        let [result] = await pool.query<ResultSetHeader>("insert into tweets(user_id, tweet_content, tweet_image) values(?,?,?)", [userId, content, tweet_image])

        return {
            tweet_id: result.insertId,
            tweet_content: content,
            tweet_image: tweet_image,
            created_at: new Date().toString()
        }


    }

    async getTweetById(tweetId: number): Promise<Tweet | null> {

        let [rows] = await pool.query<RowDataPacket[]>("select t.tweet_id, t.tweet_content, t.tweet_image, t.created_at , u.username, u.first_name, u.user_id, u.profile_picture,(select count(*) from tweet_likes l where l.tweet_id = t.tweet_id ) as like_count,(select count(*) from comments c where c.comment_id = t.tweet_id ) as comment_count from tweets t join users u on u.user_id= t.user_id where t.tweet_id = ?",[tweetId]);

        if (rows.length > 0) {
            return rows[0] as Tweet;
        }
        return null;
    }

    async deleteTweet(tweetId: number): Promise<boolean> {


        let [result] = await pool.query<ResultSetHeader>("delete from tweets where tweet_id = ?",[tweetId]);

        return result.affectedRows > 0;
    }

    async editTweet(tweetId: number, content: string, tweet_imgage: string | null): Promise<boolean> {

        let [result] = await pool.query<ResultSetHeader>("update tweets set tweet_content=? , tweet_image =? where tweet_id=?", [content, tweet_imgage, tweetId]);

        return result.affectedRows > 0


    }

    async getFeedTweets(userId: number): Promise<Tweet[] | null> {

        console.log(userId)


        let [rows] = await pool.query<RowDataPacket[]>("select t.tweet_id,t.tweet_content,t.tweet_image,t.created_at,(select count(*) from tweets rt where rt.parent_id = t.tweet_id ) as retweet_count,(select count(*) from tweet_likes l where l.tweet_id = t.tweet_id ) as like_count,(select count(*) from comments c where c.comment_id = t.tweet_id ) as comment_count,u.user_id,u.username,u.first_name,u.profile_picture from tweets t join users u on u.user_id = t.user_id where t.user_id IN (select following_id from follows_tabl where follower_id = ?)order by t.created_at desc",[userId])



        if (rows.length === 0) return null;

        return rows.map(row => ({
            tweet_id: row.tweet_id,
            tweet_content: row.tweet_content,
            tweet_image: row.tweet_image,
            created_at: row.created_at,
            like_count: row.like_count,
            comment_count: row.comment_count,
            retweet_count: row.retweet_count,
            author: {
                user_id: row.user_id,
                username: row.username,
                profile_picture: row.profile_picture
            }
        })) as Tweet[];

    }

    async getAllCommentsOfuser(user_id : number){
        let [rows] = await pool.query<RowDataPacket[]>("select c.comment_id, c.comment_content, c.created_at, c.tweet_id, u.username, u.first_name, u.last_name, u.profile_picture, u2.username as reply_to_username from comments c join users u on c.user_id = u.user_id join tweets t on c.tweet_id = t.tweet_id join users u2 on t.user_id = u2.user_id where c.user_id = ? order by c.created_at desc",[user_id]);
        return rows;
    }
    async getAllTweetsLikedByUser(user_id : number){
        let [rows] = await pool.query<RowDataPacket[]>("select t.tweet_id, t.tweet_content, t.tweet_image, t.created_at, u.username, u.first_name, u.last_name, u.profile_picture, (select count(*) from tweet_likes l2 where l2.tweet_id = t.tweet_id) as like_count, (select count(*) from comments c where c.tweet_id = t.tweet_id) as comment_count from tweets t join tweet_likes l on t.tweet_id = l.tweet_id join users u on t.user_id = u.user_id where l.user_id = 8 order by l.created_at desc",[user_id]);
        return rows;
    }
    async getUserTweets(userId: number): Promise<Tweet[] | null> {

        let [rows] = await pool.query<RowDataPacket[]>("select t.tweet_id, t.tweet_content, t.tweet_image, t.created_at , u.username, u.first_name, u.user_id, u.profile_picture,(select count(*) from tweet_likes l where l.tweet_id = t.tweet_id ) as like_count,(select count(*) from comments c where c.tweet_id = t.tweet_id ) as comment_count from tweets t join users u on u.user_id= t.user_id where t.user_id = ? order by t.created_at desc", [userId])


        if (rows.length === 0) return null;

        return rows.map(row => ({
            tweet_id: row.tweet_id,
            tweet_content: row.tweet_content,
            tweet_image: row.tweet_image,
            created_at: row.created_at,
            like_count: row.like_count,
            comment_count: row.comment_count,
            retweet_count: row.retweet_count,
            author: {
                user_id: row.user_id,
                username: row.username,
                profile_picture: row.profile_picture
            }
        })) as Tweet[];
    }

    async toggleLike(tweetId: number, userId: number): Promise<boolean> {

        console.log(tweetId, userId)
        const [isLikeExists] = await pool.query<RowDataPacket[]>("select like_id from tweet_likes where tweet_id = ? and user_id = ?", [tweetId, userId]);

        if (isLikeExists.length > 0) {

            await pool.query<ResultSetHeader>("delete from tweet_likes where tweet_id = ? and user_id = ?", [tweetId, userId])

            return false

        } else {
            await pool.query<ResultSetHeader>("insert into tweet_likes(tweet_id, user_id) values (?,?)", [tweetId, userId])

            return true
        }
    }

    async retweet(tweetId: number, userId: number): Promise<boolean> {
        const [isRetweetExists] = await pool.query<RowDataPacket[]>("select tweet_id from tweets where parent_id = ? and user_id = ?", [tweetId, userId]);

        let tweet = await this.getTweetById(tweetId);
        if (isRetweetExists.length > 0) {

            await pool.query<ResultSetHeader>("delete from tweets where parent_id = ? and user_id = ?", [tweetId, userId])

            return false

        } else {
            await pool.query<ResultSetHeader>("insert into tweets(parent_id, user_id, tweet_content) values (?,?,?)", [tweetId, userId, tweet?.tweet_content])

            return true
        }
    }

    async createReply(tweetId: number, userId: number, content: string): Promise<Comment | null> {

        let [result] = await pool.query<ResultSetHeader>("insert into comments(tweet_id, user_id, comment_content) values(?,?,?)", [tweetId, userId, content]);

        if (result.affectedRows > 0) {

            return {
                comment_id: result.insertId, // Added missing colon
                tweet_id: tweetId,
                content,
                created_at: new Date().toISOString()
            } as Comment;

        }
        return null
    }
    

    // async getReplies(tweetId: number): Promise<FullComment[] | null> {
    //     let [rows] = await pool.query<RowDataPacket[]>("select c.comment_id, c.comment_content, c.created_at, u.user_id, u.username, u.first_name, u.profile_picture from comments c join users u on u.user_id = c.user_id where c.tweet_id = ? order by c.created_at desc", [tweetId]);

    //     console.log("hi theis is from getrepiles")
    //     console.log(rows)
    //     if (rows.length === 0) return null;
    //     console.log(rows)
    //     return rows as FullComment[];


    // }
    async getReplies(tweetId: number): Promise<FullComment[] | null> {
    const [rows] = await pool.query<RowDataPacket[]>(
        "SELECT c.comment_id, c.tweet_id, c.comment_content, c.created_at, u.user_id, u.username, u.first_name, u.profile_picture FROM comments c JOIN users u ON u.user_id = c.user_id WHERE c.tweet_id = ? ORDER BY c.created_at DESC", 
        [tweetId]
    );

    if (rows.length === 0) return null;



    return rows as FullComment[]
}

}