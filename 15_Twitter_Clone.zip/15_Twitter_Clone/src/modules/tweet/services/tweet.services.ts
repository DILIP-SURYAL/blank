import { NotFoundException } from "../../../common/helper/http-exception.js";
import { TweetModel } from "../model/tweet.model.js"

export class TweetService {

    tweetModel = new TweetModel();

    async createTweet(user_id: number, tweet_content: string, tweet_image: string | null) {

        console.log("tweet image ",tweet_image)

        let tweet = await this.tweetModel.createTweet(user_id, tweet_content, tweet_image);

        return tweet

    }

    async getAllCommentsOfUser(user_id : number){
        let comments = await this.tweetModel.getAllCommentsOfuser(user_id);
        return comments;
    }

    async getAllTweetsLikedByUser(user_id : number){
        let tweets = await this.tweetModel.getAllTweetsLikedByUser(user_id);
        return tweets;
    }
    async getTweet(tweet_id: number) {

        let tweet = await this.tweetModel.getTweetById(tweet_id);
        if (!tweet) {
            throw new NotFoundException("Tweet Not Found");
        }
        return tweet;
    }
    async deleteTweet(tweet_id: number) {


        let isTweetDeleted = await this.tweetModel.deleteTweet(tweet_id);

        return isTweetDeleted;

    }
    async editTweet(tweet_id: number, tweet_content: string, tweet_image: string | null) {


        let isTweetUpdated = await this.tweetModel.editTweet(tweet_id, tweet_content, tweet_image);

        return isTweetUpdated;
    }
    async getFeed(user_id: number) {

        let tweets = await this.tweetModel.getFeedTweets(user_id);

        return tweets;
    }
    async getUserTweets(user_id: number) {

        let tweets = await this.tweetModel.getUserTweets(user_id);

        console.log(tweets)
        return tweets;

    }
    async toggleLike(tweet_id: number, user_id: number) {

        let isLiked = this.tweetModel.toggleLike(tweet_id, user_id);
        return isLiked;

    }

    async retweet(tweet_id: number, user_id: number) {

        //this will be boolean
        let ans = await this.tweetModel.retweet(tweet_id, user_id);
        return ans;
    }
    async createReply(tweet_id: number, user_id: number, content: string) {


        let comment = await this.tweetModel.createReply(tweet_id, user_id, content);

        return comment;

    } async getReplies(tweet_id: number) {

        let comments = await this.tweetModel.getReplies(tweet_id);
        return comments;
    }


}