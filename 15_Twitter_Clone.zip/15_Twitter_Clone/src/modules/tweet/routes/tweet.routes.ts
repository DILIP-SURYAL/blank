import { Router } from "express";
import type { Routes } from "../../../common/interfaces/routes.interface.js";
import { TweetController } from "../controllers/tweet.controller.js";
import { authMiddleware } from "../../../middlewares/auth.middleware.js";
import upload from "../../../middlewares/multer.middleware.js";

export class TweetRouter implements Routes{


    path = "/api"
    router = Router();

    tweetController = new TweetController()

    constructor(){
        this.initializeRoutes();
    }
    initializeRoutes(){
      this.router.get("/demo",(req, res)=>{res.json("dfkafdsdkl")})
        this.router.post("/tweet/create",authMiddleware, upload.single('tweet_image'),this.tweetController.createTweet);

      // get tweet/:id

      this.router.get("/tweet/:id", authMiddleware,this.tweetController.getTweet)
      // delete tweet/:id
      this.router.delete("/tweet/:id",authMiddleware, this.tweetController.deleteTweet)

      // patch tweet/:id
      this.router.patch("/tweet/:id", authMiddleware, upload.single('tweet_image'),this.tweetController.editTweet)

      this.router.get("/tweet-feed",authMiddleware, this.tweetController.getFeed)

      // get tweet/user/:id - all tweet from specific users
      this.router.get("/tweet/user/:id",authMiddleware, this.tweetController.getUserFeed)



      //  post tweet/:id/like  -- like unlike tweet
      this.router.post("/tweet/:id/like",authMiddleware, this.tweetController.toggleLike)

      // post tweet/:id/retweet -- retweet
      this.router.post("/tweet/:id/retweet", authMiddleware,this.tweetController.retweet)

      // post tweet/:id/comment  - comment
      this.router.post("/tweet/:id/comment",authMiddleware, this.tweetController.createReply)

      // get tweet/tweets/:id/comments -- all comments on specific tweet
      this.router.get("/tweet/:id/comments",authMiddleware, this.tweetController.getReplies)


      //this is for all comments by user
      this.router.get("/tweet/user/comments/auth",authMiddleware,this.tweetController.getAllCommentsUser)

      this.router.get("/tweet/user/likes/auth",authMiddleware,this.tweetController.getAllTweetLikedByUser)
      this.router.get("/tweet/isFollowing/:following_id",authMiddleware,this.tweetController.isFollowing);


      
    }
}