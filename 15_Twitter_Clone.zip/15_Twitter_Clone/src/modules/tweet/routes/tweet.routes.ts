import { Router } from "express";
import type { Routes } from "../../../common/interfaces/routes.interface.js";

export class TweetRouter implements Routes{


    path = "/api"
    router = Router();


    constructor(){
        this.initializeRoutes();
    }
    initializeRoutes(){
        this.router.post("/tweets")

      // get tweet/:id
      // delete tweet/:id
      // patch tweet/:id

      //get tweet/feed - all tweet from people you follow
      // get tweet/user/:id - all tweet from specific users

      //  post tweet/:id/like  -- like unlike tweet
      // post tweet/:id/retweet -- retweet
      // post tweet/:id/comment  - comment
      // get tweet/tweets/:id/comments -- all comments on specific tweet
      
    }
}