export interface TweetAuthor{
    user_id:number,
    username : string,
    first_name : string,
    profile_picture : string | null,
}

export interface Tweet{
    tweet_id : number,
    tweet_content : string,
    tweet_image :string | null,
    like_count :number,
    comment_count : number,
    retweet_count : number,
    author : TweetAuthor,
}

export interface createTweetResult{
    tweet_id:number,
    tweet_content:string,
    tweet_image : string | null,
    created_at :string
}

export interface EditTweetResult{
    tweet_id : number,
    tweet_content : string,
    updated_at :string
}

export interface ToggleLikeResult{
    liked : boolean,
}

interface RetweetResult{
    
}


interface Comment{}

interface CreateCommentResult{}
