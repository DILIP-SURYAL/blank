import type { Request, Response } from "express";
import { error, time } from "node:console";
import { sendResponse } from "../../../common/helper/send-response.js";
import type { ICreateUser } from "../../../common/interfaces/app.interfaces.js";
import { HttpException } from "../../../common/helper/http-exception.js";
import { TweetService } from "../services/tweet.services.js";

export class TweetController {


    tweetService = new TweetService();


    createTweet = async (req: Request, res: Response) => {
        try {

            let user_id = req.authUser?.user_id as number;

            const file = req.file as Express.Multer.File;

            const tweet_image = file ? file.filename : null;

            console.log(tweet_image, file)

            const { tweet_content } = req.body;

            const tweet = await this.tweetService.createTweet(user_id, tweet_content, tweet_image ? tweet_image : null);

            sendResponse(res, 200, tweet, "tweet created successfully")
        }
        catch (e) {
            console.log(e);
            let error = e instanceof Error ? e.message : "error in registring user";
            const status = e instanceof HttpException ? e.statusCode : 400;
            return sendResponse(res, status, "Failed to send otp", error);
        }
    }
    getTweet = async (req: Request, res: Response) => {
        try {

            let tweet_id = Number(req.params.id);
            let tweet = await this.tweetService.getTweet(tweet_id);
            sendResponse(res, 200, tweet, "tweet fetched successfully")

        }
        catch (e) {
            console.log(e);
            let error = e instanceof Error ? e.message : "error in registring user";
            const status = e instanceof HttpException ? e.statusCode : 400;
            return sendResponse(res, status, "Failed to send otp", error);
        }
    }
    deleteTweet = async (req: Request, res: Response) => {
        try {

            let tweet_id = Number(req.params.id);


            let isDeleted = await this.tweetService.deleteTweet(tweet_id)
            sendResponse(res, 200, isDeleted, "tweet deleted successfully")

        }
        catch (e) {
            console.log(e);
            let error = e instanceof Error ? e.message : "error in registring user";
            const status = e instanceof HttpException ? e.statusCode : 400;
            return sendResponse(res, status, "Failed to send otp", error);
        }
    }
    editTweet = async (req: Request, res: Response) => {
        try {

            let tweet_id = Number(req.params.id);

            const files = req.files as Express.Multer.File[];

            const tweet_image = files[0]?.filename as string;

            let { tweet_content } = req.body
            let isUpdated = await this.tweetService.editTweet(tweet_id, tweet_content, tweet_image)

            sendResponse(res, 200, isUpdated, "tweet Updated Successfully")
        }
        catch (e) {
            console.log(e);
            let error = e instanceof Error ? e.message : "error in registring user";
            const status = e instanceof HttpException ? e.statusCode : 400;
            return sendResponse(res, status, "Failed to send otp", error);
        }
    }


    getFeed = async (req: Request, res: Response) => {
        try {

            console.log("adsjhsdkjafhkja")
            let user_id = req.authUser?.user_id as number;


            let feed = await this.tweetService.getFeed(user_id)
            sendResponse(res, 200, feed, "feed fetched successfully")
        }
        catch (e) {
            console.log(e);
            let error = e instanceof Error ? e.message : "error in registring user";
            const status = e instanceof HttpException ? e.statusCode : 400;
            return sendResponse(res, status, "Failed to send otp", error);
        }
    }

    getUserFeed = async (req: Request, res: Response) => {
        try {

            let user_id = req.authUser?.user_id as number;


            let tweets = await this.tweetService.getUserTweets(user_id)
            sendResponse(res, 200, tweets, "feed fetched successfully")
        }
        catch (e) {
            console.log(e);
            let error = e instanceof Error ? e.message : "error in registring user";
            const status = e instanceof HttpException ? e.statusCode : 400;
            return sendResponse(res, status, "Failed to send otp", error);
        }
    }
    toggleLike = async (req: Request, res: Response) => {
        try {

            let user_id = req.authUser?.user_id as number;
            let tweet_id = Number(req.params.id);

            let isLiked = await this.tweetService.toggleLike(tweet_id, user_id);
            sendResponse(res, 200, isLiked, "like is toggeled")

        }
        catch (e) {
            console.log(e);
            let error = e instanceof Error ? e.message : "error in registring user";
            const status = e instanceof HttpException ? e.statusCode : 400;
            return sendResponse(res, status, "Failed to send otp", error);
        }
    }
    retweet = async (req: Request, res: Response) => {
        try {
            let user_id = req.authUser?.user_id as number;
            let tweet_id = Number(req.params.id);

            let isRetweeted = await this.tweetService.retweet(tweet_id, user_id);

            sendResponse(res, 200, isRetweeted, "retwited")

        }
        catch (e) {
            console.log(e);
            let error = e instanceof Error ? e.message : "error in registring user";
            const status = e instanceof HttpException ? e.statusCode : 400;
            return sendResponse(res, status, "Failed to send otp", error);
        }
    }
    createReply = async (req: Request, res: Response) => {
        try {

            let user_id = req.authUser?.user_id as number;
            let tweet_id = Number(req.params.id);

            let { comment } = req.body;
            let db_comment = await this.tweetService.createReply(tweet_id, user_id, comment);

            sendResponse(res, 200, db_comment, "commented")
        }
        catch (e) {
            console.log(e);
            let error = e instanceof Error ? e.message : "error in registring user";
            const status = e instanceof HttpException ? e.statusCode : 400;
            return sendResponse(res, status, "Failed to send otp", error);
        }
    }
    getReplies = async (req: Request, res: Response) => {
        try {

            let tweet_id = Number(req.params.id);

            let comments = await this.tweetService.getReplies(tweet_id);

            sendResponse(res, 200, comments, "all comments fetched succesfuulyu")

        }
        catch (e) {
            console.log(e);
            let error = e instanceof Error ? e.message : "error in registring user";
            const status = e instanceof HttpException ? e.statusCode : 400;
            return sendResponse(res, status, "Failed to send otp", error);
        }
    }
    getAllCommentsUser = async (req: Request, res: Response)=>{
        try {

            let comments = await this.tweetService.getAllCommentsOfUser(req.authUser?.user_id as number) ;
           
            sendResponse(res, 200, comments, "comments fetched successfully")
        }
        catch (e) {
            console.log(e);
            let error = e instanceof Error ? e.message : "error in registring user";
            const status = e instanceof HttpException ? e.statusCode : 400;
            return sendResponse(res, status, "Failed to send otp", error);
        }
    }
    getAllTweetLikedByUser = async (req: Request, res: Response)=>{
        try {

            let tweets = await this.tweetService.getAllTweetsLikedByUser(req.authUser?.user_id as number) ;
           
            sendResponse(res, 200, tweets, "liked Tweet fetched successfully")
        }
        catch (e) {
            console.log(e);
            let error = e instanceof Error ? e.message : "error in registring user";
            const status = e instanceof HttpException ? e.statusCode : 400;
            return sendResponse(res, status, "Failed to send otp", error);
        }
    }
}