import type { Request, Response } from "express";
import { error, time } from "node:console";
import svgCaptcha from "svg-captcha"
import { sendResponse } from "../../../common/helper/send-response.js";
import type { ICreateUser } from "../../../common/interfaces/app.interfaces.js";
import { AuthService } from "../services/auth.services.js";
import { HttpException } from "../../../common/helper/http-exception.js";

export class AuthController {


    authService = new AuthService();

    listLogin = async (req: Request, res: Response) => {

        try {
            res.render("auth/login")
        }
        catch (e) {
            throw e;
        }
    }

    listSignup = async (req: Request, res: Response) => {

        try {
            res.render("auth/signup", { message: "invalid use name or passroed", error: true })
        }
        catch (e) {
            throw e;
        }
    }

    listSendOtpPage = async (req: Request, res: Response) => {
        try {
            res.render("auth/send-otp-page")
        }
        catch (e) {
            throw e
        }
    }

    apiSignup = async (req: Request, res: Response) => {
        try {

            let { first_name: firstName, last_name: lastName, username, email, password, date_of_birth, timezone } = req.body;

            console.log(firstName, lastName, username, email, password, timezone, date_of_birth);

            let data = await this.authService.signup({ first_name: firstName, last_name: lastName, username, email, user_password: password, timezone, date_of_birth })

            console.log(data);

            return sendResponse(res, 200, null, "User Created Successfully !!")

        }
        catch (e) {
            console.log(e);
            let error = e instanceof Error ? e.message : "error in registring user";
            return sendResponse(res, 400, "Error in Registring User", error);
        }
    }

    apiLogin = async (req: Request, res: Response) => {
        try {

            let { emailOrUser, password } = req.body;

            console.log(emailOrUser, password);

            let data = await this.authService.login(emailOrUser, password);

            if(data.error) {
                return sendResponse(res, 401, null, "Incorrect Username Or Password");
            }
            res.cookie("refreshToken", data.data?.refreshToken, {
                httpOnly: true,
            })
            return sendResponse(res, 200, data.data?.accessToken, "User Logged In Successfully !!")

        }
        catch (e) {
            console.log(e);
            let error = e instanceof Error ? e.message : "error in registring user";
            return sendResponse(res, 400, "Failed to Login", error);
        }
    }

    sendOtp = async (req: Request, res: Response) => {
        try {
            let response = await this.authService.getOtp(req.body.email);
            if(response.success){
                req.session.isEmailVerified = true;
                req.session.user_id = response.data.user_id,
                req.session.email = req.body.email;
            return sendResponse(res, 200, null, "otp sent successfully");
        }
        }
        catch (e) {
            console.log(e);
            let error = e instanceof Error ? e.message : "error in registring user";
            const status = e instanceof HttpException ? e.statusCode : 400;
            return sendResponse(res, status, "Failed to send otp", error);
        }
    }

    verifyOtp = async (email : string, otp : string) => {
        
            let response = await this.authService.verifyOtp(email, otp);
            // req.session.isOtpVerified = true;
           
             return response.success;
        // catch (e) {
        //     console.log(e);
        //     let error = e instanceof Error ? e.message : "error in registring user";
        //     return sendResponse(res, 400, "Failed to vefiy otp", error);
        // }
    }

    resetPassword = async (req:Request, res:Response) =>{
        try{
            let {otp, newPassword} = req.body;

            let user_id = req.session.user_id as number;

            let email = req.session.email as string;
            let response = await this.verifyOtp(email, otp);
            if(response){
                let isReset = await this.authService.resetPassword(newPassword , user_id);
                req.session.isEmailVerified = false;
                
                if(isReset){
                    sendResponse(res, 200, null, "password hasbeen changed Successfully!!");
                }else{
                    sendResponse(res, 200, null, "password hasbeen changed Successfully!!");
                }
            }
            else{
                req.session.isEmailVerified = false;

                sendResponse(res, 400, null, "Incorrect Otp");
            }
        }
        catch(e){
             console.log(e);
            let error = e instanceof Error ? e.message : "error in registring user";
            const status = e instanceof HttpException ? e.statusCode : 400;
            return sendResponse(res, status, "Failed to send otp", error);
        }
    }

    showEnterOtpPage = async (req : Request , res :Response) =>{
        if(!req.session.isEmailVerified){
            return res.redirect("/send-otp-page");
        }
           return res.render("auth/enter-otp-page");
    }
    
    showMail = async(req:Request, res:Response)=>{
        try{

            if(!req.session.isEmailVerified){
                res.redirect("/send-otp-page")
            }

            let otp = await this.authService.findOtp(req.session.email as string);
            if(otp){
                res.render("auth/show-email",{otp});
            }
            else{
                res.redirect("/send-otp-page");
            }
        }
        catch (e) {
            console.log(e);
            let error = e instanceof Error ? e.message : "error in registring user";
            const status = e instanceof HttpException ? e.statusCode : 400;
            return sendResponse(res, status, "Failed to send otp", error);
        }
    }

 


    getCaptcha = async (req: Request, res: Response) => {
        try {
            const captcha = svgCaptcha.create({
                color: true,
                size: 5,
                noise: 2
            })


            req.session.captcha = captcha.text;
            res.status(200).json(captcha.data);
        }
        catch (e) {
            res.status(400).json("error creating captcha")
        }
    }

    verifyCaptcha = async (req: Request, res: Response) => {
        try {
            const captcha = req.session.captcha;
            const userCaptcha = req.body.captcha;

            console.log("Session:", captcha, "User:", userCaptcha);

            if (!captcha || !userCaptcha) {
                return sendResponse(res, 400, null, "invalid captcha", "invalid Captcha");
            }

            if (captcha.toLowerCase() === userCaptcha.toLowerCase()) {

                req.session.captcha = "";

                return sendResponse(res, 200, null, "captcha Verified Successfully");
            }

            throw new Error("Invalid Captcha code");

        } catch (e) { // 'e' is implicitly 'unknown' here
            console.error("Captcha Error:", e);

            // Check if 'e' is an actual Error object
            const errorMessage = e instanceof Error ? e.message : "Verification failed";

            return res.status(400).json({
                success: false,
                message: errorMessage
            });
        }
    };


    logout = async (req:Request , res:Response) =>{
        try{

            res.clearCookie("refreshToken");

            sendResponse(res, 200, null ,"logout successfully");

        }
        catch(e){
             console.log(e);
            let error = e instanceof Error ? e.message : "error in registring user";
            const status = e instanceof HttpException ? e.statusCode : 400;
            return sendResponse(res, status, "Failed to send otp", error);
        }
    }

}