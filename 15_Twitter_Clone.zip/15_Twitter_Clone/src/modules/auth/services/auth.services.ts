import bcrypt from "bcryptjs";
import type { ApiResponse } from "../../../common/helper/send-response.js";
import type { ICreateUser, User } from "../../../common/interfaces/app.interfaces.js";
import { UserModel } from "../../user/models/user.model.js";
import jwt from "jsonwebtoken";
import { env } from "../../../config/index.js";
import crypto from "crypto"
import pool from "../../../config/db.config.js";
import type { ResultSetHeader, RowDataPacket } from "mysql2";
                 import { BadRequestException, NotFoundException } from "../../../common/helper/http-exception.js";

export class AuthService {
    userModel = new UserModel();
    async signup(data: ICreateUser): Promise<ApiResponse<User>> {

        let user = await this.userModel.findByEmail(data.email);

        if (user) throw new Error("user is alreay Exists !!");

        user = await this.userModel.findByUsername(data.username)


        if (user) throw new Error("User is already Exists !!");
        data.user_password = await bcrypt.hash(data.user_password, 10);
        let db_user = await this.userModel.create(data);
        return { data: db_user, message: "user created successfully !", error: "error creating user" }
    }
    async login(emailOrUser: string, password: string): Promise<ApiResponse<{ accessToken: string, refreshToken: string }>> {
        let user = await this.userModel.findByEmail(emailOrUser);

        console.log(emailOrUser, password)

        if (!user) {
            user = await this.userModel.findByUsername(emailOrUser);
        }


        if (!user) {
            throw new Error("User Doesnot exists please register");
        }

        const isMatch = await bcrypt.compare(password, user.user_password);

        if (isMatch) {
            
        console.log("is",isMatch)
            const tokens = this.generateTokens(user.user_id, user.email);
            return {
                data: tokens,
                message: "User logged in successfully!",
            };
        } else {

        console.log("isffafd",isMatch)
            return {
                data: null,
                message: "Invalid password!",
                error: "Authentication failed"
            };
        }
    }
    

    async resetPassword(password : string, user_id : number){
        if(!password){
            throw new NotFoundException("password not found");
        }

        password = await bcrypt.hash(password, 10);
        let isUpdated= await this.userModel.updatePassword(password, user_id);

        return isUpdated;
    }
    async findOtp(email :string){
        let otp = await this.userModel.getOtp(email);
        return otp
    }


    async getOtp(email: string) {
        let user = await this.userModel.findByEmail(email);

        if (!user) {
            throw new Error("OTP has Been Send to your Account");
        }

        let canGetOtp = await this.userModel.canGetOtp(email);

        if (!canGetOtp) {
            throw new BadRequestException("Unable to get OTP");
        }
        let otp = crypto.randomInt(100000, 999999).toString();

        let query = `insert into password_resets(otp, email, expires_at) values(?,?, NOW() + INTERVAL 2 MINUTE)`;

        await pool.query<ResultSetHeader>("DELETE FROM password_resets WHERE email = ?", [email]);
        let [result] = await pool.query<ResultSetHeader>(query, [otp, email]);

        return {
            success: true,
            data: {otp, user_id : user.user_id},
            message: "Otp generated Successfully !!"
        }
    }
    async verifyOtp(email: string, userOtp: string) {
        const query = "SELECT * FROM password_resets WHERE otp = ? AND email = ? AND expires_at > NOW()";  
        console.log(userOtp, email)

        const [rows] = await pool.query<RowDataPacket[]>(query, [userOtp, email]);

        if (rows.length === 0) {
            throw new Error("Invalid or expired OTP code.");
        }

        return {
            success: true,
            message: "OTP verified successfully. You can now reset your password."
        };
    }

    generateTokens = (userId: number | string, email: string) => {
        const accessToken = jwt.sign(
            { user_id: userId, email },
            env.JWT_SECRET as string,
            { expiresIn: '1h' }
        );

        const refreshToken = jwt.sign(
            { id: userId, email },
            env.JWT_REFRESH_SECRET as string,
            { expiresIn: '40s' }
        );

        return { accessToken, refreshToken };
    };
}