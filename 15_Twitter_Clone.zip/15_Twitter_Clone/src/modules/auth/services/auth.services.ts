import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import crypto from "crypto";
import type { ResultSetHeader, RowDataPacket } from "mysql2";

import { env } from "../../../config/index.js";
import pool from "../../../config/db.config.js";
import { UserModel } from "../../user/models/user.model.js";

import type { ApiResponse } from  "../../user/interfaces/user.interfaces.js";
import type { ICreateUser, IUserPublic } from  "../../user/interfaces/user.interfaces.js";

// ─── Constants ─────────────────────────────────────────────────────────────────
const SALT_ROUNDS = 10;
const OTP_MIN     = 100_000;
const OTP_MAX     = 999_999;

// ─── Local Types ───────────────────────────────────────────────────────────────
interface ITokenPayload {
  id: number;
  email: string;
}

interface IAuthTokens {
  accessToken: string;
  refreshToken: string;
}

// ─── Service ───────────────────────────────────────────────────────────────────
export class AuthService {
  private userModel = new UserModel();

  // ── Signup ──────────────────────────────────────────────────────────────────
  async signup(data: ICreateUser): Promise<ApiResponse<IUserPublic>> {
    const [byEmail, byUsername] = await Promise.all([
      this.userModel.findByEmail(data.email),
      this.userModel.findByUsername(data.username),
    ]);

    if (byEmail)    throw new Error("An account with this email already exists.");
    if (byUsername) throw new Error("An account with this username already exists.");

    data.user_password = await bcrypt.hash(data.user_password, SALT_ROUNDS);

    const newUser = await this.userModel.create(data);

    // Strip password + internal fields before returning
    const publicUser: IUserPublic = {
      user_id:         newUser.user_id,
      username:        newUser.username,
      first_name:      newUser.first_name,
      last_name:       newUser.last_name,
      bio:             newUser.bio,
      profile_picture: newUser.profile_picture,
      cover_image:     newUser.cover_image,
      created_at:      newUser.created_at,
    };

    return { data: publicUser, message: "Account created successfully." };
  }

  // ── Login ───────────────────────────────────────────────────────────────────
  async login(
    emailOrUsername: string,
    password: string
  ): Promise<ApiResponse<IAuthTokens>> {
    const user =
      (await this.userModel.findByEmail(emailOrUsername)) ??
      (await this.userModel.findByUsername(emailOrUsername));

    if (!user) throw new Error("No account found with that email or username.");

    const isPasswordValid = await bcrypt.compare(password, user.user_password);
    if (!isPasswordValid) throw new Error("Incorrect password.");

    const tokens = this.generateTokens({ id: user.user_id, email: user.email });

    return { data: tokens, message: "Logged in successfully." };
  }

  // ── Request OTP ─────────────────────────────────────────────────────────────
  async requestOtp(email: string): Promise<ApiResponse<null>> {
    const user = await this.userModel.findByEmail(email);
    if (!user) throw new Error("No account found with that email.");

    const otp = crypto.randomInt(OTP_MIN, OTP_MAX).toString();

    // Delete any existing OTP for this email, then insert fresh one
    await pool.query<ResultSetHeader>(
      "DELETE FROM password_resets WHERE email = ?",
      [email]
    );
    await pool.query<ResultSetHeader>(
      "INSERT INTO password_resets (otp, email, expires_at) VALUES (?, ?, NOW() + INTERVAL 2 MINUTE)",
      [otp, email]
    );

    // TODO: pass otp to your mail service here e.g. await mailService.sendOtp(email, otp)
    // Never return the raw OTP in the response — it's a security leak
    return { data: null, message: "OTP sent to your email." };
  }

  // ── Verify OTP ──────────────────────────────────────────────────────────────
  async verifyOtp(email: string, otp: string): Promise<ApiResponse<null>> {
    const [rows] = await pool.query<RowDataPacket[]>(
      `SELECT 1 FROM password_resets
       WHERE email = ? AND otp = ? AND expires_at > NOW()
       LIMIT 1`,
      [email, otp]
    );

    if (rows.length === 0) throw new Error("Invalid or expired OTP.");

    // Consume the OTP immediately — prevents reuse
    await pool.query<ResultSetHeader>(
      "DELETE FROM password_resets WHERE email = ?",
      [email]
    );

    return { data: null, message: "OTP verified. You may now reset your password." };
  }

  // ── Token Generator ─────────────────────────────────────────────────────────
  private generateTokens(payload: ITokenPayload): IAuthTokens {
    const accessToken = jwt.sign(
      payload,
      env.JWT_SECRET as string,
      { expiresIn: "15m" }
    );

    const refreshToken = jwt.sign(
      payload,
      env.JWT_REFRESH_SECRET as string,
      { expiresIn: "7d" }
    );

    return { accessToken, refreshToken };
  }
}