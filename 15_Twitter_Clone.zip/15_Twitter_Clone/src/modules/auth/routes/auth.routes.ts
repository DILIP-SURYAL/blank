import { Router } from "express";
import type { Routes } from "../../../common/interfaces/routes.interface.js";
import { AuthController } from "../controllers/auth.controller.js";

export class AuthRouter implements Routes {
  path = "/";
  router = Router();
  private authController = new AuthController();

  constructor() {
    this.initializeRoutes();
  }

  private initializeRoutes(): void {
    this.registerPageRoutes();
    this.registerApiRoutes();
  }

  private registerPageRoutes() {
    this.router.get("/", this.authController.listLogin);
    this.router.get("/signup", this.authController.listSignup);
    this.router.get("/send-otp-page", this.authController.listSendOtpPage);
    this.router.get("/show-email", (_req, res) => res.render("auth/show-email"));
    this.router.get("/home", (_req, res) => res.render("user/home"));
  }

  private registerApiRoutes() {
    this.router.get("/getCaptcha", this.authController.getCaptcha);
    this.router.post("/verifyCaptcha", this.authController.verifyCaptcha);
    this.router.post("/signup", this.authController.apiSignup);
    this.router.post("/login", this.authController.apiLogin);
    this.router.post("/otp/send", this.authController.sendOtp);
    this.router.post("/otp/verify", this.authController.verifyOtp);
  }
}