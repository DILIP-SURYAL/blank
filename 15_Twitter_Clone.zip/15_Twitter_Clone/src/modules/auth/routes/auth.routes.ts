import  { Router } from "express";
import type { Routes } from "../../../common/interfaces/routes.interface.js";
import { AuthController } from "../controllers/auth.controller.js";


export class AuthRouter implements Routes{


    path =  "/";

    router = Router();

    authController = new AuthController();

    constructor(){
        this.initializeRoutes();
    }


    initializeRoutes(){
        this.router.get("/",this.authController.listLogin);
        this.router.get("/signup",this.authController.listSignup);
        this.router.get("/send-otp-page",this.authController.listSendOtpPage);
        this.router.get("/show-email",(req, res)=>{res.render("auth/show-email")});

        this.router.get("/getCaptcha",this.authController.getCaptcha);
        this.router.post("/verifyCaptcha",this.authController.verifyCaptcha);
        this.router.post("/apiSignup",this.authController.apiSignup);
        this.router.post("/apiLogin",this.authController.apiLogin);
        this.router.post("/sendOtp", this.authController.sendOtp);
        this.router.post("/verifyOtp", this.authController.verifyOtp);

    }
}