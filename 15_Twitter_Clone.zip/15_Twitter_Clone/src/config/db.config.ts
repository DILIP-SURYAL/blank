import mysql from "mysql2/promise"
import { env } from "./index.js";




const pool = mysql.createPool({
  host: env.DB_HOST,
  user: env.DB_USER,
  password:env.DB_PASSWORD,
  database: env.DB_NAME,
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
  timezone: '+00:00',
  decimalNumbers: true,
});

export const connectDB = async() : Promise<void>=>{
    try{
        const connection = await pool.getConnection();
        console.log("connection is established successfully with database...")
    }
    catch(e){
        console.log(e);
        throw e;
    }
}

export default pool;
