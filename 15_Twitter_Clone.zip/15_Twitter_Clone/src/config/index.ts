/**
 * config/index.ts — Environment Configuration
 *
 * Central place for all environment variables.
 * Validates and exports a typed `env` object so the rest of the app
 * never touches process.env directly.
 *
 * When adding a new env var:
 *   1. Add it to .env.example with a comment
 *   2. Add it here with a type and default value
 *   3. Update the README
 */

import dotenv from 'dotenv';

dotenv.config();

export const env = {
  PORT: parseInt(process.env.PORT || '3000', 10),
  SITE_URL: process.env.SITE_URL || 'http://localhost:3000',

  // Database
  DB_HOST: process.env.DB_HOST || 'localhost',
  DB_NAME: process.env.DB_NAME || 'twitter_db',
  DB_USER: process.env.DB_USER || 'user',
  DB_PASSWORD: process.env.DB_PASSWORD || 'password',

  // JWT
  JWT_SECRET: process.env.JWT_SECRET || 'change-me',
  JWT_EXPIRES_IN: process.env.JWT_EXPIRES_IN || '1d',
  JWT_REFRESH_SECRET: process.env.JWT_REFRESH_SECRET || 'change-me-refresh',
  JWT_REFRESH_EXPIRES_IN: process.env.JWT_REFRESH_EXPIRES_IN || '7d',

  //   // File Upload
  //   FILE_STORAGE_DRIVER: process.env.FILE_STORAGE_DRIVER || 'local',
  //   LOCAL_UPLOAD_DIR: process.env.LOCAL_UPLOAD_DIR || 'uploads',
  //   MAX_UPLOAD_SIZE_MB: parseInt(process.env.MAX_UPLOAD_SIZE_MB || '5', 10),
};
