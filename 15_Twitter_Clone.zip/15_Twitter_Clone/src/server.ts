/**
 * server.ts — Process Bootstrap
 *
 * This is the main entry point of the application.
 * It initializes the database connection, starts the HTTP server,
 * optionally sets up Socket.IO, and registers graceful shutdown handlers.
 *
 * Boot sequence:
 *   1. Load environment variables
 *   2. Connect to the database
 *   3. Create the Express app via createApp()
 *   4. Start the HTTP server
 *   5. (Optional) Initialize Socket.IO
 *   6. Register process signal handlers for graceful shutdown
 */

import { createApp } from './app.js';
import { env } from './config/index.js';
async function bootstrap() {
  try {
    // Step 1: Connect to database
    // await connectDatabase();

    const app = createApp();

    // Step 5: Start listening
    app.listen(env.PORT, () => {
      console.log(`Server running on http://localhost:${env.PORT}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
  }
}

bootstrap();
