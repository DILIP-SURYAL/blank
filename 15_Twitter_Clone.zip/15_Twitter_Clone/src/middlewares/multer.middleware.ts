import multer from "multer";
import type { Request } from "express";

const diskConfig = multer.diskStorage({
    destination: (req: Request, file: Express.Multer.File, cb: (error: Error | null, filename: string) => void) => {
        cb(null, "public/upload");
    },
    filename: (req: Request, file: Express.Multer.File, cb: (error: Error | null, filename: string) => void) => {
        console.log("dsdaf from multer")
        cb(null, Date.now() + "-" + file.originalname);
        console.log("dsdaf from multer", Date.now() + "-" + file.originalname)

    }
});

const upload = multer({
    storage: diskConfig,
    limits: {
        fileSize: 1024 * 1024 * 50
    }
});

export default upload; 