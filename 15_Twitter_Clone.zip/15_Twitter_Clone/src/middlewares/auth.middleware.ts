import type { Response, Request, NextFunction } from "express";
import jwt from "jsonwebtoken";
import { env } from "../config/index.js";
import type { User } from "../common/interfaces/app.interfaces.js";
export function authMiddleware(req:Request, res:Response, next:NextFunction){
    try{
        let authHeader = req.headers.authorization;

        if(!authHeader || !authHeader.startsWith("Bearer ")){
            throw new Error("unauthorized");
        }

        let token = authHeader.split(" ")[1] as string;


        let decode = jwt.verify(token, env.JWT_SECRET);

        req.authUser = decode as User;

        next();
    }
    catch(e){
        console.log(e);
        throw e;
    }
}