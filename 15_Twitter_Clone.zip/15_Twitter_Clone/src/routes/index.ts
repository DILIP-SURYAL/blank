import { Router } from 'express';
import type { Routes } from '../common/interfaces/routes.interface.js';
import { AuthRouter } from '../modules/auth/routes/auth.routes.js';

export function buildApiRouter() {
  let router = Router();

  let routes: Routes[] = [
    new AuthRouter(),
  ];

  for (let route of routes) {
    router.use(route.path, route.router);
  }

  return router;
}
