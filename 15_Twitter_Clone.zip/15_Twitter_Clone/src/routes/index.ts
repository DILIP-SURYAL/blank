import { Router } from 'express';
import type { Routes } from '../common/interfaces/routes.interface.js';
import { AuthRouter } from '../modules/auth/routes/auth.routes.js';
import { UserRouter } from '../modules/user/routes/user.routes.js';

export function buildApiRouter() {
  let router = Router();

  let routes: Routes[] = [
    new AuthRouter(),
    new UserRouter(),
  ];

  for (let route of routes) {
    router.use(route.path, route.router);
  }

  return router;
}
