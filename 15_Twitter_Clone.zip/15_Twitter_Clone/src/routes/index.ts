import { Router } from 'express';
import type { Routes } from '../common/interfaces/routes.interface.js';
import { AuthRouter } from '../modules/auth/routes/auth.routes.js';
import { UserRouter } from '../modules/user/routes/user.routes.js';
import { TweetRouter } from '../modules/tweet/routes/tweet.routes.js';
import { FollowRouter } from '../modules/follow/routes/follow.routes.js';

export function buildApiRouter() {
  let router = Router();

  let routes: Routes[] = [
    new AuthRouter(),
    new UserRouter(),
    new TweetRouter(),
    new FollowRouter(),
  ];

  for (let route of routes) {
    router.use(route.path, route.router);
  }

  return router;
}
