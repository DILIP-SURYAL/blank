import "express-session"
import type { Request  } from "express";
import type { User } from "../common/interfaces/app.interfaces.ts";

declare global{
  namespace Express{
    interface Request{
      authUser?:AuthUser
    }
  }
}

declare module "express-session"{
  interface Session{
    captcha:string
  }
} 