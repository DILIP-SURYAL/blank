declare namespace NodeJS {
  interface ProcessEnv {
    PORT: string;
    SITE_URL: string;

    // Database ------
    DB_HOST: string;
    DB_NAME: string;
    DB_USER: string;
    DB_PASSWORD: string;

    // JWT  -------------
    JWT_SECRET: string;
    JWT_EXPIRES_IN: string;
    JWT_REFRESH_SECRET: string;
    JWT_REFRESH_EXPIRES_IN: string;

    // // multer ---------------
    // FILE_STORAGE_DRIVER: 'local' | 's3';
    // LOCAL_UPLOAD_DIR: string;
    // MAX_UPLOAD_SIZE_MB: string;
  }
}
