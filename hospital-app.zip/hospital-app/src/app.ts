import express, { Request, Response } from 'express';
import path from 'path';
import dotenv from 'dotenv';
import doctorRoutes from './routes/doctor.routes';
import patientRoutes from './routes/patient.routes';
import { DoctorController } from './controllers/doctor.controller';
import { PatientController } from './controllers/patient.controller';
import { upload } from './config/multer';
import { globalErrorHandler, notFoundHandler } from './middlewares/error.middleware';

dotenv.config();

const app = express();

// ─── View Engine ──────────────────────────────────────────────────────────────
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// ─── Static Files ─────────────────────────────────────────────────────────────
app.use('/uploads', express.static(path.join(process.cwd(), 'uploads')));
app.use('/public', express.static(path.join(__dirname, 'public')));

// ─── Body Parsers ─────────────────────────────────────────────────────────────
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// ─── Request Logger ───────────────────────────────────────────────────────────
app.use((req, _res, next) => {
  console.log(`[${new Date().toISOString()}] ${req.method} ${req.originalUrl}`);
  next();
});

// ─── HTML View Routes ─────────────────────────────────────────────────────────
app.get('/', (_req: Request, res: Response) => res.redirect('/doctors'));
app.use('/doctors', doctorRoutes);
app.use('/patients', patientRoutes);

// ─── REST API Routes ──────────────────────────────────────────────────────────
app.get('/api/doctors', DoctorController.apiList);
app.get('/api/doctors/:id', DoctorController.apiGetOne);
app.post('/api/doctors', upload.single('profile_image'), DoctorController.apiCreate);
app.put('/api/doctors/:id', upload.single('profile_image'), DoctorController.apiUpdate);
app.delete('/api/doctors/:id', DoctorController.apiDelete);

app.get('/api/patients', PatientController.apiList);
app.get('/api/patients/:id', PatientController.apiGetOne);
app.post('/api/patients', PatientController.apiCreate);
app.put('/api/patients/:id', PatientController.apiUpdate);
app.delete('/api/patients/:id', PatientController.apiDelete);

// ─── Error Handling ───────────────────────────────────────────────────────────
app.use(notFoundHandler);
app.use(globalErrorHandler);

export default app;
