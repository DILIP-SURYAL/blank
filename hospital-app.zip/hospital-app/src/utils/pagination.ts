import { PaginationParams, PaginatedResult } from '../types/index.d';

const DEFAULT_PAGE = 1;
const DEFAULT_LIMIT = 10;
const MAX_LIMIT = 100;

/**
 * Parses and validates pagination query parameters.
 */
export const parsePagination = (
  pageStr?: string,
  limitStr?: string
): PaginationParams => {
  let page = parseInt(pageStr ?? String(DEFAULT_PAGE), 10);
  let limit = parseInt(limitStr ?? String(DEFAULT_LIMIT), 10);

  if (isNaN(page) || page < 1) page = DEFAULT_PAGE;
  if (isNaN(limit) || limit < 1) limit = DEFAULT_LIMIT;
  if (limit > MAX_LIMIT) limit = MAX_LIMIT;

  const offset = (page - 1) * limit;

  return { page, limit, offset };
};

/**
 * Wraps data into a standardized paginated response shape.
 */
export const buildPaginatedResult = <T>(
  data: T[],
  total: number,
  params: PaginationParams
): PaginatedResult<T> => {
  const totalPages = Math.ceil(total / params.limit);

  return {
    data,
    total,
    totalPages,
    currentPage: params.page,
    limit: params.limit,
  };
};
