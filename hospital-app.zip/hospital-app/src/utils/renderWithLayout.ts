import { Response } from 'express';
import path from 'path';
import ejs from 'ejs';

/**
 * Renders a view inside layout.ejs.
 * Usage: renderWithLayout(res, 'doctors/index', { title: 'Doctors', ... })
 */
export const renderWithLayout = async (
  res: Response,
  view: string,
  locals: Record<string, unknown> = {}
): Promise<void> => {
  const viewsDir = path.join(__dirname, '..', 'views');

  // Render the inner view to a string
  const body = await ejs.renderFile(path.join(viewsDir, `${view}.ejs`), locals);

  // Render the layout with body injected
  const html = await ejs.renderFile(path.join(viewsDir, 'layout.ejs'), {
    ...locals,
    body,
  });

  res.send(html);
};
