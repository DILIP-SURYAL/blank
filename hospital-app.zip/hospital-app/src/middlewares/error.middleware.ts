import { Request, Response, NextFunction } from 'express';

export class AppError extends Error {
  public readonly statusCode: number;
  public readonly isOperational: boolean;

  constructor(message: string, statusCode: number, isOperational = true) {
    super(message);
    this.statusCode = statusCode;
    this.isOperational = isOperational;
    Object.setPrototypeOf(this, new.target.prototype);
    Error.captureStackTrace(this);
  }
}

export const notFoundHandler = (req: Request, _res: Response, next: NextFunction): void => {
  next(new AppError(`Route not found: ${req.method} ${req.originalUrl}`, 404));
};

export const globalErrorHandler = async (
  err: Error | AppError,
  req: Request,
  res: Response,
  _next: NextFunction
): Promise<void> => {
  const isDev = process.env['NODE_ENV'] === 'development';
  let statusCode = 500;
  let message = 'Internal Server Error';

  if (err instanceof AppError) {
    statusCode = err.statusCode;
    message = err.message;
  }

  console.error(`[${new Date().toISOString()}] ${req.method} ${req.originalUrl} - ${statusCode}: ${err.message}`);
  if (isDev) console.error(err.stack);

  const wantsJson = req.headers.accept?.includes('application/json') || req.path.startsWith('/api');

  if (wantsJson) {
    res.status(statusCode).json({
      success: false, statusCode, message,
      ...(isDev && { stack: err.stack }),
    });
  } else {
    try {
      const { renderWithLayout } = await import('../utils/renderWithLayout');
      await renderWithLayout(res.status(statusCode), 'error', {
        title: `Error ${statusCode}`, statusCode, message,
        stack: isDev ? err.stack : null,
      });
    } catch {
      res.status(statusCode).send(`<h1>${statusCode} - ${message}</h1>`);
    }
  }
};
