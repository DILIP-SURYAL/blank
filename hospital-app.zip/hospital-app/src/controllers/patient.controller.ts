import { Request, Response, NextFunction } from 'express';
import { PatientService } from '../services/patient.service';
import { DoctorService } from '../services/doctor.service';
import { AppError } from '../middlewares/error.middleware';
import { renderWithLayout } from '../utils/renderWithLayout';
import { z } from 'zod';

const createPatientSchema = z.object({
  name: z.string().min(2, 'Name must be at least 2 characters').max(100),
  age: z.coerce.number().int().min(0, 'Age cannot be negative').max(150),
  disease: z.string().min(2, 'Disease must be at least 2 characters').max(200),
  doctor_id: z.coerce.number().int().positive('Doctor ID must be a positive integer'),
});

const updatePatientSchema = createPatientSchema.partial();

export const PatientController = {
  async listPage(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { name, disease, page, limit } = req.query as Record<string, string>;
      const result = await PatientService.getAll({ name, disease, page: +page || 1, limit: +limit || 10 });
      await renderWithLayout(res, 'patients/index', {
        title: 'Patients', ...result,
        filters: { name, disease }, messages: req.query['msg'],
      });
    } catch (err) { next(err); }
  },

  async newPage(_req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const doctors = await DoctorService.getAllForDropdown();
      await renderWithLayout(res, 'patients/form', { title: 'Add Patient', patient: null, doctors, errors: null });
    } catch (err) { next(err); }
  },

  async editPage(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const [patient, doctors] = await Promise.all([
        PatientService.getById(+req.params['id']),
        DoctorService.getAllForDropdown(),
      ]);
      await renderWithLayout(res, 'patients/form', { title: 'Edit Patient', patient, doctors, errors: null });
    } catch (err) { next(err); }
  },

  async detailPage(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const patient = await PatientService.getById(+req.params['id']);
      await renderWithLayout(res, 'patients/detail', { title: patient.name, patient });
    } catch (err) { next(err); }
  },

  async apiList(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { name, disease, page, limit } = req.query as Record<string, string>;
      const result = await PatientService.getAll({ name, disease, page: +page || 1, limit: +limit || 10 });
      res.json({ success: true, ...result });
    } catch (err) { next(err); }
  },

  async apiGetOne(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const patient = await PatientService.getById(+req.params['id']);
      res.json({ success: true, data: patient });
    } catch (err) { next(err); }
  },

  async apiCreate(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const parsed = createPatientSchema.safeParse(req.body);
      if (!parsed.success) throw new AppError(parsed.error.errors.map(e => e.message).join(', '), 422);
      const patient = await PatientService.create(parsed.data);
      res.status(201).json({ success: true, data: patient });
    } catch (err) { next(err); }
  },

  async apiUpdate(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const parsed = updatePatientSchema.safeParse(req.body);
      if (!parsed.success) throw new AppError(parsed.error.errors.map(e => e.message).join(', '), 422);
      const patient = await PatientService.update(+req.params['id'], parsed.data);
      res.json({ success: true, data: patient });
    } catch (err) { next(err); }
  },

  async apiDelete(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      await PatientService.delete(+req.params['id']);
      res.json({ success: true, message: 'Patient deleted successfully' });
    } catch (err) { next(err); }
  },

  async formCreate(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const parsed = createPatientSchema.safeParse(req.body);
      if (!parsed.success) {
        const doctors = await DoctorService.getAllForDropdown();
        await renderWithLayout(res, 'patients/form', { title: 'Add Patient', patient: null, doctors, errors: parsed.error.errors });
        return;
      }
      await PatientService.create(parsed.data);
      res.redirect('/patients?msg=Patient+created+successfully');
    } catch (err) { next(err); }
  },

  async formUpdate(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const parsed = updatePatientSchema.safeParse(req.body);
      if (!parsed.success) {
        const [patient, doctors] = await Promise.all([
          PatientService.getById(+req.params['id']),
          DoctorService.getAllForDropdown(),
        ]);
        await renderWithLayout(res, 'patients/form', { title: 'Edit Patient', patient, doctors, errors: parsed.error.errors });
        return;
      }
      await PatientService.update(+req.params['id'], parsed.data);
      res.redirect('/patients?msg=Patient+updated+successfully');
    } catch (err) { next(err); }
  },

  async formDelete(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      await PatientService.delete(+req.params['id']);
      res.redirect('/patients?msg=Patient+deleted+successfully');
    } catch (err) { next(err); }
  },
};
