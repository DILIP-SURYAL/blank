import { Request, Response, NextFunction } from 'express';
import { DoctorService } from '../services/doctor.service';
import { AppError } from '../middlewares/error.middleware';
import { renderWithLayout } from '../utils/renderWithLayout';
import { z } from 'zod';

const createDoctorSchema = z.object({
  name: z.string().min(2, 'Name must be at least 2 characters').max(100),
  specialization: z.string().min(2, 'Specialization must be at least 2 characters').max(100),
  experience: z.coerce.number().int().min(0, 'Experience cannot be negative').max(60),
});

const updateDoctorSchema = createDoctorSchema.partial();

export const DoctorController = {
  async listPage(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { name, specialization, page, limit } = req.query as Record<string, string>;
      const result = await DoctorService.getAll({ name, specialization, page: +page || 1, limit: +limit || 10 });
      await renderWithLayout(res, 'doctors/index', {
        title: 'Doctors', ...result,
        filters: { name, specialization }, messages: req.query['msg'],
      });
    } catch (err) { next(err); }
  },

  async newPage(_req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      await renderWithLayout(res, 'doctors/form', { title: 'Add Doctor', doctor: null, errors: null });
    } catch (err) { next(err); }
  },

  async editPage(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const doctor = await DoctorService.getById(+req.params['id']);
      await renderWithLayout(res, 'doctors/form', { title: 'Edit Doctor', doctor, errors: null });
    } catch (err) { next(err); }
  },

  async detailPage(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const doctor = await DoctorService.getById(+req.params['id']);
      await renderWithLayout(res, 'doctors/detail', { title: doctor.name, doctor });
    } catch (err) { next(err); }
  },

  async apiList(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { name, specialization, page, limit } = req.query as Record<string, string>;
      const result = await DoctorService.getAll({ name, specialization, page: +page || 1, limit: +limit || 10 });
      res.json({ success: true, ...result });
    } catch (err) { next(err); }
  },

  async apiGetOne(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const doctor = await DoctorService.getById(+req.params['id']);
      res.json({ success: true, data: doctor });
    } catch (err) { next(err); }
  },

  async apiCreate(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const parsed = createDoctorSchema.safeParse(req.body);
      if (!parsed.success) throw new AppError(parsed.error.errors.map(e => e.message).join(', '), 422);
      const profileImage = req.file ? `/uploads/${req.file.filename}` : undefined;
      const doctor = await DoctorService.create({ ...parsed.data, profile_image: profileImage });
      res.status(201).json({ success: true, data: doctor });
    } catch (err) { next(err); }
  },

  async apiUpdate(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const parsed = updateDoctorSchema.safeParse(req.body);
      if (!parsed.success) throw new AppError(parsed.error.errors.map(e => e.message).join(', '), 422);
      const profileImage = req.file ? `/uploads/${req.file.filename}` : undefined;
      const updateData = { ...parsed.data, ...(profileImage && { profile_image: profileImage }) };
      const doctor = await DoctorService.update(+req.params['id'], updateData);
      res.json({ success: true, data: doctor });
    } catch (err) { next(err); }
  },

  async apiDelete(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      await DoctorService.delete(+req.params['id']);
      res.json({ success: true, message: 'Doctor deleted successfully' });
    } catch (err) { next(err); }
  },

  async formCreate(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const parsed = createDoctorSchema.safeParse(req.body);
      if (!parsed.success) {
        await renderWithLayout(res, 'doctors/form', { title: 'Add Doctor', doctor: null, errors: parsed.error.errors });
        return;
      }
      const profileImage = req.file ? `/uploads/${req.file.filename}` : undefined;
      await DoctorService.create({ ...parsed.data, profile_image: profileImage });
      res.redirect('/doctors?msg=Doctor+created+successfully');
    } catch (err) { next(err); }
  },

  async formUpdate(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const parsed = updateDoctorSchema.safeParse(req.body);
      if (!parsed.success) {
        const doctor = await DoctorService.getById(+req.params['id']);
        await renderWithLayout(res, 'doctors/form', { title: 'Edit Doctor', doctor, errors: parsed.error.errors });
        return;
      }
      const profileImage = req.file ? `/uploads/${req.file.filename}` : undefined;
      const updateData = { ...parsed.data, ...(profileImage && { profile_image: profileImage }) };
      await DoctorService.update(+req.params['id'], updateData);
      res.redirect('/doctors?msg=Doctor+updated+successfully');
    } catch (err) { next(err); }
  },

  async formDelete(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      await DoctorService.delete(+req.params['id']);
      res.redirect('/doctors?msg=Doctor+deleted+successfully');
    } catch (err) { next(err); }
  },
};
