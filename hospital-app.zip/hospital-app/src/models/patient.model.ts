import pool from '../config/db';
import { Patient, CreatePatientDTO, UpdatePatientDTO, PatientFilters } from '../types/index.d';
import { RowDataPacket, ResultSetHeader } from 'mysql2/promise';

// ─── Patient Model ────────────────────────────────────────────────────────────

export const PatientModel = {
  /**
   * Find all non-deleted patients with optional filtering, joining doctor name.
   */
  async findAll(filters: PatientFilters, offset: number, limit: number): Promise<Patient[]> {
    const conditions: string[] = ['p.is_deleted = 0'];
    const values: (string | number)[] = [];

    if (filters.name) {
      conditions.push('p.name LIKE ?');
      values.push(`%${filters.name}%`);
    }
    if (filters.disease) {
      conditions.push('p.disease LIKE ?');
      values.push(`%${filters.disease}%`);
    }

    const where = `WHERE ${conditions.join(' AND ')}`;
    const sql = `
      SELECT p.*, d.name AS doctor_name
      FROM patients p
      LEFT JOIN doctors d ON p.doctor_id = d.id AND d.is_deleted = 0
      ${where}
      ORDER BY p.created_at DESC
      LIMIT ? OFFSET ?
    `;
    values.push(limit, offset);

    const [rows] = await pool.query<RowDataPacket[]>(sql, values);
    return rows as Patient[];
  },

  /**
   * Count all non-deleted patients matching filters.
   */
  async countAll(filters: PatientFilters): Promise<number> {
    const conditions: string[] = ['is_deleted = 0'];
    const values: string[] = [];

    if (filters.name) {
      conditions.push('name LIKE ?');
      values.push(`%${filters.name}%`);
    }
    if (filters.disease) {
      conditions.push('disease LIKE ?');
      values.push(`%${filters.disease}%`);
    }

    const where = `WHERE ${conditions.join(' AND ')}`;
    const [rows] = await pool.query<RowDataPacket[]>(
      `SELECT COUNT(*) AS count FROM patients ${where}`,
      values
    );
    return (rows[0] as { count: number }).count;
  },

  /**
   * Find a single patient by ID (non-deleted), joining doctor name.
   */
  async findById(id: number): Promise<Patient | null> {
    const [rows] = await pool.query<RowDataPacket[]>(
      `SELECT p.*, d.name AS doctor_name
       FROM patients p
       LEFT JOIN doctors d ON p.doctor_id = d.id AND d.is_deleted = 0
       WHERE p.id = ? AND p.is_deleted = 0`,
      [id]
    );
    return rows.length ? (rows[0] as Patient) : null;
  },

  /**
   * Insert a new patient record.
   */
  async create(data: CreatePatientDTO): Promise<number> {
    const [result] = await pool.query<ResultSetHeader>(
      'INSERT INTO patients (name, age, disease, doctor_id) VALUES (?, ?, ?, ?)',
      [data.name, data.age, data.disease, data.doctor_id]
    );
    return result.insertId;
  },

  /**
   * Update an existing patient by ID.
   */
  async update(id: number, data: UpdatePatientDTO): Promise<boolean> {
    const fields: string[] = [];
    const values: (string | number)[] = [];

    if (data.name !== undefined) { fields.push('name = ?'); values.push(data.name); }
    if (data.age !== undefined) { fields.push('age = ?'); values.push(data.age); }
    if (data.disease !== undefined) { fields.push('disease = ?'); values.push(data.disease); }
    if (data.doctor_id !== undefined) { fields.push('doctor_id = ?'); values.push(data.doctor_id); }

    if (fields.length === 0) return false;

    values.push(id);
    const [result] = await pool.query<ResultSetHeader>(
      `UPDATE patients SET ${fields.join(', ')} WHERE id = ? AND is_deleted = 0`,
      values
    );
    return result.affectedRows > 0;
  },

  /**
   * Soft-delete a patient by ID.
   */
  async softDelete(id: number): Promise<boolean> {
    const [result] = await pool.query<ResultSetHeader>(
      'UPDATE patients SET is_deleted = 1 WHERE id = ? AND is_deleted = 0',
      [id]
    );
    return result.affectedRows > 0;
  },
};
