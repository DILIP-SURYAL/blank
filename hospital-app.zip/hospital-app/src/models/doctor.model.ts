import pool from '../config/db';
import { Doctor, CreateDoctorDTO, UpdateDoctorDTO, DoctorFilters } from '../types/index.d';
import { RowDataPacket, ResultSetHeader } from 'mysql2/promise';

// ─── Doctor Model ─────────────────────────────────────────────────────────────

export const DoctorModel = {
  /**
   * Find all non-deleted doctors with optional filtering and pagination.
   */
  async findAll(filters: DoctorFilters, offset: number, limit: number): Promise<Doctor[]> {
    const conditions: string[] = ['d.is_deleted = 0'];
    const values: (string | number)[] = [];

    if (filters.name) {
      conditions.push('d.name LIKE ?');
      values.push(`%${filters.name}%`);
    }
    if (filters.specialization) {
      conditions.push('d.specialization LIKE ?');
      values.push(`%${filters.specialization}%`);
    }

    const where = `WHERE ${conditions.join(' AND ')}`;
    const sql = `SELECT * FROM doctors d ${where} ORDER BY d.created_at DESC LIMIT ? OFFSET ?`;
    values.push(limit, offset);

    const [rows] = await pool.query<RowDataPacket[]>(sql, values);
    return rows as Doctor[];
  },

  /**
   * Count all non-deleted doctors matching filters.
   */
  async countAll(filters: DoctorFilters): Promise<number> {
    const conditions: string[] = ['is_deleted = 0'];
    const values: string[] = [];

    if (filters.name) {
      conditions.push('name LIKE ?');
      values.push(`%${filters.name}%`);
    }
    if (filters.specialization) {
      conditions.push('specialization LIKE ?');
      values.push(`%${filters.specialization}%`);
    }

    const where = `WHERE ${conditions.join(' AND ')}`;
    const [rows] = await pool.query<RowDataPacket[]>(
      `SELECT COUNT(*) AS count FROM doctors ${where}`,
      values
    );
    return (rows[0] as { count: number }).count;
  },

  /**
   * Find a single doctor by ID (non-deleted).
   */
  async findById(id: number): Promise<Doctor | null> {
    const [rows] = await pool.query<RowDataPacket[]>(
      'SELECT * FROM doctors WHERE id = ? AND is_deleted = 0',
      [id]
    );
    return rows.length ? (rows[0] as Doctor) : null;
  },

  /**
   * Insert a new doctor record.
   */
  async create(data: CreateDoctorDTO): Promise<number> {
    const [result] = await pool.query<ResultSetHeader>(
      'INSERT INTO doctors (name, specialization, experience, profile_image) VALUES (?, ?, ?, ?)',
      [data.name, data.specialization, data.experience, data.profile_image ?? null]
    );
    return result.insertId;
  },

  /**
   * Update an existing doctor by ID.
   */
  async update(id: number, data: UpdateDoctorDTO): Promise<boolean> {
    const fields: string[] = [];
    const values: (string | number | null)[] = [];

    if (data.name !== undefined) { fields.push('name = ?'); values.push(data.name); }
    if (data.specialization !== undefined) { fields.push('specialization = ?'); values.push(data.specialization); }
    if (data.experience !== undefined) { fields.push('experience = ?'); values.push(data.experience); }
    if (data.profile_image !== undefined) { fields.push('profile_image = ?'); values.push(data.profile_image); }

    if (fields.length === 0) return false;

    values.push(id);
    const [result] = await pool.query<ResultSetHeader>(
      `UPDATE doctors SET ${fields.join(', ')} WHERE id = ? AND is_deleted = 0`,
      values
    );
    return result.affectedRows > 0;
  },

  /**
   * Soft-delete a doctor by ID.
   */
  async softDelete(id: number): Promise<boolean> {
    const [result] = await pool.query<ResultSetHeader>(
      'UPDATE doctors SET is_deleted = 1 WHERE id = ? AND is_deleted = 0',
      [id]
    );
    return result.affectedRows > 0;
  },

  /**
   * Fetch lightweight list for dropdown usage.
   */
  async findAllForDropdown(): Promise<Pick<Doctor, 'id' | 'name' | 'specialization'>[]> {
    const [rows] = await pool.query<RowDataPacket[]>(
      'SELECT id, name, specialization FROM doctors WHERE is_deleted = 0 ORDER BY name ASC'
    );
    return rows as Pick<Doctor, 'id' | 'name' | 'specialization'>[];
  },
};
