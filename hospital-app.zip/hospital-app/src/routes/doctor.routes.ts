import { Router } from 'express';
import { DoctorController } from '../controllers/doctor.controller';
import { upload } from '../config/multer';

const router = Router();

// ─── HTML View Routes ─────────────────────────────────────────────────────────

router.get('/', DoctorController.listPage);
router.get('/new', DoctorController.newPage);
router.get('/:id/edit', DoctorController.editPage);
router.get('/:id', DoctorController.detailPage);

// Form submit routes (method override via POST)
router.post('/', upload.single('profile_image'), DoctorController.formCreate);
router.post('/:id', upload.single('profile_image'), DoctorController.formUpdate);
router.post('/:id/delete', DoctorController.formDelete);

export default router;
