import { Router } from 'express';
import { PatientController } from '../controllers/patient.controller';

const router = Router();

// ─── HTML View Routes ─────────────────────────────────────────────────────────

router.get('/', PatientController.listPage);
router.get('/new', PatientController.newPage);
router.get('/:id/edit', PatientController.editPage);
router.get('/:id', PatientController.detailPage);

// Form submit routes
router.post('/', PatientController.formCreate);
router.post('/:id', PatientController.formUpdate);
router.post('/:id/delete', PatientController.formDelete);

export default router;
