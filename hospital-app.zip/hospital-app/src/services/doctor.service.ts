import { DoctorModel } from '../models/doctor.model';
import { AppError } from '../middlewares/error.middleware';
import { parsePagination, buildPaginatedResult } from '../utils/pagination';
import {
  Doctor,
  CreateDoctorDTO,
  UpdateDoctorDTO,
  DoctorFilters,
  PaginatedResult,
} from '../types/index.d';
import fs from 'fs';
import path from 'path';

// ─── Doctor Service ───────────────────────────────────────────────────────────

export const DoctorService = {
  /**
   * Retrieve paginated and filtered list of doctors.
   */
  async getAll(filters: DoctorFilters): Promise<PaginatedResult<Doctor>> {
    const pagination = parsePagination(String(filters.page ?? 1), String(filters.limit ?? 10));
    const [doctors, total] = await Promise.all([
      DoctorModel.findAll(filters, pagination.offset, pagination.limit),
      DoctorModel.countAll(filters),
    ]);
    return buildPaginatedResult(doctors, total, pagination);
  },

  /**
   * Get a single doctor or throw 404.
   */
  async getById(id: number): Promise<Doctor> {
    const doctor = await DoctorModel.findById(id);
    if (!doctor) throw new AppError(`Doctor with ID ${id} not found`, 404);
    return doctor;
  },

  /**
   * Create a new doctor.
   */
  async create(data: CreateDoctorDTO): Promise<Doctor> {
    const id = await DoctorModel.create(data);
    return this.getById(id);
  },

  /**
   * Update a doctor. If a new image is uploaded, delete the old file.
   */
  async update(id: number, data: UpdateDoctorDTO): Promise<Doctor> {
    const existing = await this.getById(id);

    // Remove old image if a new one is provided
    if (data.profile_image && existing.profile_image) {
      const oldPath = path.join(process.cwd(), 'uploads', path.basename(existing.profile_image));
      if (fs.existsSync(oldPath)) {
        fs.unlinkSync(oldPath);
      }
    }

    const updated = await DoctorModel.update(id, data);
    if (!updated) throw new AppError('Failed to update doctor', 500);
    return this.getById(id);
  },

  /**
   * Soft-delete a doctor and remove their profile image.
   */
  async delete(id: number): Promise<void> {
    const doctor = await this.getById(id);

    if (doctor.profile_image) {
      const imgPath = path.join(process.cwd(), 'uploads', path.basename(doctor.profile_image));
      if (fs.existsSync(imgPath)) {
        fs.unlinkSync(imgPath);
      }
    }

    const deleted = await DoctorModel.softDelete(id);
    if (!deleted) throw new AppError('Failed to delete doctor', 500);
  },

  /**
   * Get all doctors for dropdown/select components.
   */
  async getAllForDropdown() {
    return DoctorModel.findAllForDropdown();
  },
};
