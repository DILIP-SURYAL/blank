import { PatientModel } from '../models/patient.model';
import { DoctorModel } from '../models/doctor.model';
import { AppError } from '../middlewares/error.middleware';
import { parsePagination, buildPaginatedResult } from '../utils/pagination';
import {
  Patient,
  CreatePatientDTO,
  UpdatePatientDTO,
  PatientFilters,
  PaginatedResult,
} from '../types/index.d';

// ─── Patient Service ──────────────────────────────────────────────────────────

export const PatientService = {
  /**
   * Retrieve paginated and filtered list of patients.
   */
  async getAll(filters: PatientFilters): Promise<PaginatedResult<Patient>> {
    const pagination = parsePagination(String(filters.page ?? 1), String(filters.limit ?? 10));
    const [patients, total] = await Promise.all([
      PatientModel.findAll(filters, pagination.offset, pagination.limit),
      PatientModel.countAll(filters),
    ]);
    return buildPaginatedResult(patients, total, pagination);
  },

  /**
   * Get a single patient or throw 404.
   */
  async getById(id: number): Promise<Patient> {
    const patient = await PatientModel.findById(id);
    if (!patient) throw new AppError(`Patient with ID ${id} not found`, 404);
    return patient;
  },

  /**
   * Create a new patient, validating that doctor exists.
   */
  async create(data: CreatePatientDTO): Promise<Patient> {
    const doctor = await DoctorModel.findById(data.doctor_id);
    if (!doctor) throw new AppError(`Doctor with ID ${data.doctor_id} not found`, 400);

    const id = await PatientModel.create(data);
    return this.getById(id);
  },

  /**
   * Update a patient, validating doctor if provided.
   */
  async update(id: number, data: UpdatePatientDTO): Promise<Patient> {
    await this.getById(id); // ensures patient exists

    if (data.doctor_id !== undefined) {
      const doctor = await DoctorModel.findById(data.doctor_id);
      if (!doctor) throw new AppError(`Doctor with ID ${data.doctor_id} not found`, 400);
    }

    const updated = await PatientModel.update(id, data);
    if (!updated) throw new AppError('Failed to update patient', 500);
    return this.getById(id);
  },

  /**
   * Soft-delete a patient.
   */
  async delete(id: number): Promise<void> {
    await this.getById(id); // ensures patient exists
    const deleted = await PatientModel.softDelete(id);
    if (!deleted) throw new AppError('Failed to delete patient', 500);
  },
};
