// ─── Doctor Types ────────────────────────────────────────────────────────────

export interface Doctor {
  id: number;
  name: string;
  specialization: string;
  experience: number;
  profile_image: string | null;
  is_deleted: boolean;
  created_at: Date;
}

export interface CreateDoctorDTO {
  name: string;
  specialization: string;
  experience: number;
  profile_image?: string;
}

export interface UpdateDoctorDTO {
  name?: string;
  specialization?: string;
  experience?: number;
  profile_image?: string;
}

// ─── Patient Types ────────────────────────────────────────────────────────────

export interface Patient {
  id: number;
  name: string;
  age: number;
  disease: string;
  doctor_id: number;
  doctor_name?: string; // joined field
  is_deleted: boolean;
  created_at: Date;
}

export interface CreatePatientDTO {
  name: string;
  age: number;
  disease: string;
  doctor_id: number;
}

export interface UpdatePatientDTO {
  name?: string;
  age?: number;
  disease?: string;
  doctor_id?: number;
}

// ─── Pagination Types ─────────────────────────────────────────────────────────

export interface PaginationParams {
  page: number;
  limit: number;
  offset: number;
}

export interface PaginatedResult<T> {
  data: T[];
  total: number;
  totalPages: number;
  currentPage: number;
  limit: number;
}

// ─── Query Filter Types ───────────────────────────────────────────────────────

export interface DoctorFilters {
  name?: string;
  specialization?: string;
  page?: number;
  limit?: number;
}

export interface PatientFilters {
  name?: string;
  disease?: string;
  page?: number;
  limit?: number;
}

// ─── Express Request Extensions ───────────────────────────────────────────────

import { Request } from 'express';

export interface TypedRequest<B = Record<string, unknown>, Q = Record<string, unknown>> extends Request {
  body: B;
  query: Q & Record<string, string | undefined>;
}
