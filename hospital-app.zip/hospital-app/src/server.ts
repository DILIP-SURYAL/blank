import app from './app';
import { connectDB } from './config/db';

const PORT = parseInt(process.env['PORT'] ?? '3000', 10);

const startServer = async (): Promise<void> => {
  await connectDB();

  const server = app.listen(PORT, () => {
    console.log(`🚀 Server running at http://localhost:${PORT}`);
    console.log(`📋 Doctors:  http://localhost:${PORT}/doctors`);
    console.log(`🏥 Patients: http://localhost:${PORT}/patients`);
    console.log(`🔌 API:      http://localhost:${PORT}/api`);
  });

  // Graceful shutdown
  const shutdown = (signal: string) => {
    console.log(`\n${signal} received. Shutting down gracefully...`);
    server.close(() => {
      console.log('✅ HTTP server closed.');
      process.exit(0);
    });
  };

  process.on('SIGTERM', () => shutdown('SIGTERM'));
  process.on('SIGINT', () => shutdown('SIGINT'));
};

startServer().catch((err) => {
  console.error('❌ Failed to start server:', err);
  process.exit(1);
});
