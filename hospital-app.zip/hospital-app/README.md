# 🏥 MediCore HMS — Hospital Management System

A production-ready backend built with **Node.js + Express + TypeScript + MySQL + EJS**.

---

## Tech Stack

| Layer       | Technology              |
|-------------|-------------------------|
| Runtime     | Node.js 18+             |
| Framework   | Express.js 4            |
| Language    | TypeScript 5 (strict)   |
| Database    | MySQL 8+ (mysql2/promise, pooled) |
| Views       | EJS with custom layout  |
| File Upload | Multer                  |
| Validation  | Zod                     |

---

## Project Structure

```
src/
 ├── config/
 │    ├── db.ts            # MySQL connection pool
 │    └── multer.ts        # File upload config
 ├── controllers/
 │    ├── doctor.controller.ts
 │    └── patient.controller.ts
 ├── routes/
 │    ├── doctor.routes.ts
 │    └── patient.routes.ts
 ├── services/
 │    ├── doctor.service.ts   # Business logic
 │    └── patient.service.ts
 ├── models/
 │    ├── doctor.model.ts     # DB queries
 │    └── patient.model.ts
 ├── middlewares/
 │    └── error.middleware.ts # Global error handler + AppError
 ├── utils/
 │    ├── pagination.ts       # Reusable pagination utility
 │    └── renderWithLayout.ts # EJS layout wrapper
 ├── views/
 │    ├── layout.ejs
 │    ├── error.ejs
 │    ├── doctors/  (index, form, detail)
 │    └── patients/ (index, form, detail)
 ├── types/
 │    └── index.d.ts          # All interfaces & DTOs
 ├── app.ts
 └── server.ts
```

---

## Setup Instructions

### 1. Prerequisites

- Node.js 18+
- MySQL 8+
- npm or yarn

### 2. Clone & Install

```bash
git clone <repo-url>
cd hospital-app
npm install
```

### 3. Environment Variables

```bash
cp .env.example .env
```

Edit `.env`:

```env
PORT=3000
DB_HOST=localhost
DB_USER=root
DB_PASSWORD=your_mysql_password
DB_NAME=hospital_db
NODE_ENV=development
```

### 4. Database Setup

```bash
mysql -u root -p < schema.sql
```

This creates the `hospital_db` database, all tables with indexes + foreign keys, and seeds sample data.

### 5. Run the Application

**Development (with hot reload):**
```bash
npm run dev
```

**Production build:**
```bash
npm run build
npm start
```

### 6. Access the App

| URL | Description |
|-----|-------------|
| http://localhost:3000/doctors | Doctors list UI |
| http://localhost:3000/patients | Patients list UI |
| http://localhost:3000/api/doctors | REST API |
| http://localhost:3000/api/patients | REST API |

---

## REST API Reference

### Doctors

#### List doctors (with pagination & filtering)
```
GET /api/doctors?page=1&limit=10&name=arjun&specialization=cardiology
```

**Response:**
```json
{
  "success": true,
  "data": [...],
  "total": 12,
  "totalPages": 2,
  "currentPage": 1,
  "limit": 10
}
```

#### Get single doctor
```
GET /api/doctors/1
```

#### Create doctor (multipart/form-data)
```
POST /api/doctors
Content-Type: multipart/form-data

name=Dr. John Smith
specialization=Cardiology
experience=10
profile_image=<file>
```

#### Update doctor
```
PUT /api/doctors/1
Content-Type: multipart/form-data

name=Dr. John Updated
experience=12
```

#### Delete doctor (soft delete)
```
DELETE /api/doctors/1
```

---

### Patients

#### List patients
```
GET /api/patients?page=1&limit=10&name=amit&disease=diabetes
```

#### Get single patient
```
GET /api/patients/1
```

#### Create patient
```
POST /api/patients
Content-Type: application/json

{
  "name": "Ramesh Kumar",
  "age": 45,
  "disease": "Hypertension",
  "doctor_id": 1
}
```

#### Update patient
```
PUT /api/patients/1
Content-Type: application/json

{
  "age": 46,
  "disease": "Hypertension Stage 2",
  "doctor_id": 2
}
```

#### Delete patient (soft delete)
```
DELETE /api/patients/1
```

---

## Sample cURL Commands

```bash
# List all doctors
curl http://localhost:3000/api/doctors

# Search doctors
curl "http://localhost:3000/api/doctors?name=arjun&page=1&limit=5"

# Create a doctor
curl -X POST http://localhost:3000/api/doctors \
  -F "name=Dr. Test" \
  -F "specialization=Neurology" \
  -F "experience=8"

# Create a patient
curl -X POST http://localhost:3000/api/patients \
  -H "Content-Type: application/json" \
  -d '{"name":"Jane Doe","age":32,"disease":"Migraine","doctor_id":1}'

# Update patient
curl -X PUT http://localhost:3000/api/patients/1 \
  -H "Content-Type: application/json" \
  -d '{"age":33}'

# Delete a doctor
curl -X DELETE http://localhost:3000/api/doctors/1
```

---

## Features

- ✅ Full CRUD for Doctors and Patients
- ✅ Page-based pagination (First/Prev/Next/Last buttons)
- ✅ Search & filter by name, specialization, disease
- ✅ File upload with type & size validation (Multer)
- ✅ Soft delete support (`is_deleted` flag)
- ✅ Zod schema validation on all inputs
- ✅ Custom `AppError` class with global error handler
- ✅ MySQL connection pooling (10 connections)
- ✅ Strict TypeScript — no `any`, all interfaces typed
- ✅ Clean architecture: Controller → Service → Model
- ✅ EJS views with dark-themed responsive UI
- ✅ REST API + HTML views from same codebase

---

## Error Handling

All errors return a consistent shape from the API:

```json
{
  "success": false,
  "statusCode": 404,
  "message": "Doctor with ID 99 not found"
}
```

Custom `AppError` class supports operational vs programmer errors. The global middleware logs all errors with timestamps.
