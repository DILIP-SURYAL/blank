-- ============================================================
-- MediCore HMS — MySQL Schema
-- Run this file once to initialize your database
-- ============================================================

CREATE DATABASE IF NOT EXISTS hospital_db
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE hospital_db;

-- ─── Doctors Table ────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS doctors (
  id            INT UNSIGNED    NOT NULL AUTO_INCREMENT,
  name          VARCHAR(100)    NOT NULL,
  specialization VARCHAR(100)   NOT NULL,
  experience    TINYINT UNSIGNED NOT NULL DEFAULT 0 COMMENT 'Years of experience',
  profile_image VARCHAR(255)    NULL      DEFAULT NULL,
  is_deleted    TINYINT(1)      NOT NULL  DEFAULT 0  COMMENT 'Soft delete flag',
  created_at    TIMESTAMP       NOT NULL  DEFAULT CURRENT_TIMESTAMP,
  updated_at    TIMESTAMP       NOT NULL  DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  PRIMARY KEY (id),
  INDEX idx_doctors_name           (name),
  INDEX idx_doctors_specialization (specialization),
  INDEX idx_doctors_is_deleted     (is_deleted)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─── Patients Table ───────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS patients (
  id         INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  name       VARCHAR(100)  NOT NULL,
  age        TINYINT UNSIGNED NOT NULL,
  disease    VARCHAR(200)  NOT NULL,
  doctor_id  INT UNSIGNED  NOT NULL,
  is_deleted TINYINT(1)    NOT NULL DEFAULT 0 COMMENT 'Soft delete flag',
  created_at TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  PRIMARY KEY (id),
  INDEX idx_patients_name      (name),
  INDEX idx_patients_disease   (disease),
  INDEX idx_patients_doctor_id (doctor_id),
  INDEX idx_patients_is_deleted(is_deleted),

  CONSTRAINT fk_patients_doctor
    FOREIGN KEY (doctor_id) REFERENCES doctors (id)
    ON DELETE RESTRICT
    ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─── Seed Data (Optional) ────────────────────────────────────────────────────
INSERT INTO doctors (name, specialization, experience) VALUES
  ('Dr. Arjun Mehta',    'Cardiology',     15),
  ('Dr. Priya Sharma',   'Neurology',      10),
  ('Dr. Rahul Gupta',    'Orthopedics',    8),
  ('Dr. Sneha Patel',    'Dermatology',    6),
  ('Dr. Vikram Joshi',   'Pediatrics',     12),
  ('Dr. Ananya Reddy',   'Oncology',       9),
  ('Dr. Karan Malhotra', 'Endocrinology',  7),
  ('Dr. Divya Nair',     'Psychiatry',     11),
  ('Dr. Rohan Desai',    'Gastroenterology', 5),
  ('Dr. Meera Iyer',     'Ophthalmology',  14),
  ('Dr. Suresh Kapoor',  'Urology',        16),
  ('Dr. Lakshmi Bose',   'Pulmonology',    13);

INSERT INTO patients (name, age, disease, doctor_id) VALUES
  ('Amit Sharma',    45, 'Hypertension',          1),
  ('Sunita Devi',    62, 'Coronary Artery Disease', 1),
  ('Ravi Kumar',     38, 'Migraine',              2),
  ('Kavya Singh',    29, 'Epilepsy',              2),
  ('Mohan Lal',      55, 'Knee Arthritis',        3),
  ('Pooja Verma',    34, 'Psoriasis',             4),
  ('Aryan Kapoor',    8, 'Asthma',                5),
  ('Neha Gupta',     27, 'Breast Cancer',         6),
  ('Prakash Jain',   50, 'Type 2 Diabetes',       7),
  ('Rina Agarwal',   41, 'Depression',            8),
  ('Sunil Rao',      48, 'Crohn\'s Disease',      9),
  ('Anjali Mishra',  36, 'Glaucoma',              10),
  ('Deepak Tiwari',  60, 'Kidney Stones',         11),
  ('Rekha Pandey',   53, 'COPD',                  12),
  ('Vivek Sharma',   31, 'Anxiety Disorder',      8),
  ('Geeta Kumari',   44, 'Gallstones',            9);
